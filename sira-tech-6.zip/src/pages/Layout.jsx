
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, 
  Activity, 
  Cpu, 
  FileText, 
  Settings, 
  HelpCircle,
  LogOut,
  Menu,
  MapPin,
  PlusCircle,
  Leaf,
  Info,
  User,
  Home,
  Users,
  ShieldCheck
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690180d00e5abc697ac29b36/8f5adb738_9F04B826-60A9-46FE-9302-C05424F7FF57.PNG";

// Navegação organizada por seções
const navigationSections = [
  {
    label: "Monitoramento",
    items: [
      {
        title: "Painel Geral",
        url: createPageUrl("Dashboard"),
        icon: LayoutDashboard,
      },
      {
        title: "Mapa GPS",
        url: createPageUrl("Mapa"),
        icon: MapPin,
      },
    ]
  },
  {
    label: "Gestão",
    items: [
      {
        title: "Fazendas",
        url: createPageUrl("Fazendas"),
        icon: Home,
      },
      {
        title: "Animais",
        url: createPageUrl("Animais"),
        icon: Activity,
      },
      {
        title: "Dispositivos IoT",
        url: createPageUrl("Dispositivos"),
        icon: Cpu,
      },
    ]
  },
  {
    label: "Equipe",
    items: [
      {
        title: "Membros",
        url: createPageUrl("GestaoEquipe"),
        icon: Users,
      },
    ]
  },
  {
    label: "Análises",
    items: [
      {
        title: "Relatórios",
        url: createPageUrl("Relatorios"),
        icon: FileText,
      },
      {
        title: "Sustentabilidade",
        url: createPageUrl("Sustentabilidade"),
        icon: Leaf,
      },
    ]
  },
  {
    label: "Sistema",
    items: [
      {
        title: "Meu Perfil",
        url: createPageUrl("Perfil"),
        icon: User,
      },
      {
        title: "Configurações",
        url: createPageUrl("Configuracoes"),
        icon: Settings,
      },
      {
        title: "Suporte",
        url: createPageUrl("Suporte"),
        icon: HelpCircle,
      },
      {
        title: "Privacidade",
        url: createPageUrl("PoliticaPrivacidade"),
        icon: ShieldCheck,
      },
      {
        title: "Sobre",
        url: createPageUrl("Sobre"),
        icon: Info,
      },
    ]
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [sessionTimeout, setSessionTimeout] = React.useState(null);

  const resetSessionTimeout = React.useCallback(() => {
    if (sessionTimeout) clearTimeout(sessionTimeout);
    
    const timeout = setTimeout(() => {
      alert('⚠️ Sua sessão expirou por inatividade. Faça login novamente.');
      base44.auth.logout();
    }, 30 * 60 * 1000);
    
    setSessionTimeout(timeout);
  }, [sessionTimeout]);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        resetSessionTimeout();
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();

    const handleActivity = () => {
      resetSessionTimeout();
    };

    window.addEventListener('mousedown', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('touchstart', handleActivity);

    return () => {
      window.removeEventListener('mousedown', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
      if (sessionTimeout) clearTimeout(sessionTimeout);
    };
  }, [resetSessionTimeout, sessionTimeout]);

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair?')) {
      base44.auth.logout();
    }
  };

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --neon-green: #00ff41;
          --neon-green-dark: #00cc33;
          --dark-bg: #0a0e0a;
          --dark-card: #0f1410;
          --dark-border: #1a2f1a;
        }
        
        @keyframes neon-pulse {
          0%, 100% { 
            box-shadow: 0 0 10px rgba(0,255,65,0.5), 0 0 20px rgba(0,255,65,0.3), 0 0 30px rgba(0,255,65,0.2);
          }
          50% { 
            box-shadow: 0 0 15px rgba(0,255,65,0.8), 0 0 30px rgba(0,255,65,0.5), 0 0 45px rgba(0,255,65,0.3);
          }
        }
        
        .neon-text {
          color: #00ff41;
          text-shadow: 0 0 10px rgba(0,255,65,0.8);
        }
        
        .neon-border {
          animation: neon-pulse 2s ease-in-out infinite;
        }
      `}</style>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
        <Sidebar className="border-r border-emerald-500/20 bg-black">
          <SidebarHeader className="border-b border-emerald-500/20 p-6 bg-black">
            <div className="flex items-center justify-center">
              <div className="w-20 h-20 flex items-center justify-center">
                <img 
                  src={LOGO_URL} 
                  alt="SIRA-TECH Logo" 
                  className="w-full h-full object-contain drop-shadow-2xl"
                  style={{filter: 'drop-shadow(0 0 30px rgba(0,255,65,0.5))'}}
                />
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3 bg-black overflow-y-auto">
            {navigationSections.map((section, sectionIndex) => (
              <SidebarGroup key={sectionIndex} className="mb-2">
                <SidebarGroupLabel className="text-xs font-black text-emerald-400/70 uppercase tracking-widest px-3 py-2 mb-1">
                  {section.label}
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {section.items.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`transition-all duration-300 rounded-xl mb-1 ${
                            location.pathname === item.url 
                              ? 'bg-emerald-500 text-black shadow-lg font-black neon-border' 
                              : 'text-emerald-400 bg-transparent hover:bg-emerald-500/20 hover:text-emerald-300 border border-transparent hover:border-emerald-500/30'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                            <item.icon className="w-5 h-5" />
                            <span className="font-bold text-sm">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
                {sectionIndex < navigationSections.length - 1 && (
                  <Separator className="my-2 bg-emerald-500/10" />
                )}
              </SidebarGroup>
            ))}
          </SidebarContent>

          <SidebarFooter className="border-t border-emerald-500/20 p-4 bg-black">
            <div className="space-y-3">
              <div className="flex items-center gap-3 px-2">
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/50 border-2 border-emerald-400">
                  <span className="text-black font-black text-sm">
                    {user?.full_name?.[0]?.toUpperCase() || 'U'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-emerald-400 text-sm truncate">
                    {user?.full_name || 'Usuário'}
                  </p>
                  <p className="text-xs text-emerald-500/70 truncate">{user?.email || ''}</p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="w-full justify-start gap-2 bg-transparent border-emerald-500/30 text-emerald-400 hover:bg-red-950/50 hover:text-red-400 hover:border-red-500 transition-all font-bold"
              >
                <LogOut className="w-4 h-4" />
                Sair
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-black/80 backdrop-blur-xl border-b border-emerald-500/20 px-6 py-4 md:hidden sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-emerald-500/20 p-2 rounded-lg transition-colors duration-200 text-emerald-400">
                <Menu className="w-5 h-5" />
              </SidebarTrigger>
              <div className="flex items-center gap-3">
                <img 
                  src={LOGO_URL} 
                  alt="SIRA-TECH Logo" 
                  className="w-10 h-10 object-contain"
                  style={{filter: 'drop-shadow(0 0 10px rgba(0,255,65,0.5))'}}
                />
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
