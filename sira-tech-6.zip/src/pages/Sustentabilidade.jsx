
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Leaf, Target, Users, Droplet, Wind, Recycle, TreePine, Heart } from "lucide-react";

export default function Sustentabilidade() {
  const ods = [
    {
      numero: "ODS 2",
      titulo: "Fome Zero e Agricultura Sustentável",
      descricao: "Aumentar a produtividade agrícola através de tecnologia IoT",
      icon: Leaf,
      color: "from-yellow-500 to-amber-600"
    },
    {
      numero: "ODS 9",
      titulo: "Indústria, Inovação e Infraestrutura",
      descricao: "Implementação de tecnologia IoT para monitoramento inteligente",
      icon: Target,
      color: "from-orange-500 to-red-600"
    },
    {
      numero: "ODS 12",
      titulo: "Consumo e Produção Responsáveis",
      descricao: "Otimização de recursos e redução de desperdícios",
      icon: Recycle,
      color: "from-emerald-500 to-green-600"
    },
    {
      numero: "ODS 13",
      titulo: "Ação Contra a Mudança Global do Clima",
      descricao: "Redução de emissões de CO₂ através de energia solar",
      icon: Wind,
      color: "from-emerald-500 to-green-600"
    },
    {
      numero: "ODS 15",
      titulo: "Vida Terrestre",
      descricao: "Preservação do bem-estar animal e do meio ambiente",
      icon: TreePine,
      color: "from-emerald-500 to-green-600"
    },
  ];

  const metricas = [
    {
      titulo: "Emissões de CO₂ Evitadas",
      valor: "850 kg",
      descricao: "Por ano com uso de energia solar",
      icon: Wind,
    },
    {
      titulo: "Economia de Água",
      valor: "15.000 L",
      descricao: "Por mês com irrigação inteligente",
      icon: Droplet,
    },
    {
      titulo: "Energia Renovável",
      valor: "85%",
      descricao: "Do sistema alimentado por solar",
      icon: Leaf,
    },
    {
      titulo: "Bem-estar Animal",
      valor: "+35%",
      descricao: "Melhoria na qualidade de vida",
      icon: Heart,
    },
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Sustentabilidade e ODS
          </h1>
          <p className="text-slate-400 mt-2 font-medium">
            Como o SIRA-TECH contribui para os Objetivos de Desenvolvimento Sustentável
          </p>
        </div>

        {/* Métricas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {metricas.map((metrica, index) => {
            const IconComponent = metrica.icon;
            return (
              <Card key={index} className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <IconComponent className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">{metrica.titulo}</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {metrica.valor}
                      </p>
                      <p className="text-xs text-slate-500">{metrica.descricao}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* ODS Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ods.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <Card key={index} className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 border-b border-emerald-900/30">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-emerald-500/20 rounded-xl backdrop-blur-sm border border-emerald-500/30">
                      <IconComponent className="w-6 h-6 text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-xs text-emerald-400 font-bold">{item.numero}</p>
                      <CardTitle className="text-base font-black text-slate-200">
                        {item.titulo}
                      </CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-sm text-slate-400 leading-relaxed">
                    {item.descricao}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Info Card */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                <Leaf className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <h3 className="font-black text-emerald-400 text-lg mb-2">Compromisso com o Futuro</h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  O SIRA-TECH está alinhado com os Objetivos de Desenvolvimento Sustentável (ODS) da ONU, 
                  promovendo práticas sustentáveis na pecuária através de tecnologia IoT, energia solar e 
                  gestão inteligente de recursos. Nosso sistema não apenas melhora a eficiência produtiva, 
                  mas também contribui ativamente para a preservação do meio ambiente e o bem-estar animal.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
