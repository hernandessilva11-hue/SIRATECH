import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, Download, FileText, Navigation, Activity } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function RelatorioMovimentacao() {
  const [periodoInicio, setPeriodoInicio] = useState('');
  const [periodoFim, setPeriodoFim] = useState('');
  const [relatorioGerado, setRelatorioGerado] = useState(null);

  const { data: animais = [] } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const gerarRelatorio = () => {
    const animaisRastreados = animais.filter(a => a.localizacao_atual).length;
    const distanciaMedia = 12.5;
    const distanciaTotal = animaisRastreados * distanciaMedia * 30;

    const dadosGrafico = [
      { dia: '01', distancia: 11.2 },
      { dia: '05', distancia: 13.5 },
      { dia: '10', distancia: 12.8 },
      { dia: '15', distancia: 14.2 },
      { dia: '20', distancia: 11.9 },
      { dia: '25', distancia: 13.1 },
      { dia: '30', distancia: 12.4 },
    ];

    setRelatorioGerado({
      periodo: { inicio: periodoInicio, fim: periodoFim },
      animaisRastreados,
      distanciaMedia,
      distanciaTotal,
      dadosGrafico,
    });
  };

  const exportarPDF = () => {
    alert('Exportando relatório em PDF... (funcionalidade em desenvolvimento)');
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Relatório de Movimentação
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Rastreamento GPS e padrões de deslocamento
            </p>
          </div>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <FileText className="w-5 h-5 text-emerald-400" />
              Configurar Relatório
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Data Início</Label>
                <Input
                  type="date"
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Data Fim</Label>
                <Input
                  type="date"
                  value={periodoFim}
                  onChange={(e) => setPeriodoFim(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={gerarRelatorio}
                  className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {relatorioGerado && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Activity className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Animais Rastreados</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.animaisRastreados}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Navigation className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Distância Média/Dia</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.distanciaMedia} km
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <MapPin className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Distância Total</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.distanciaTotal.toFixed(0)} km
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                  <Navigation className="w-5 h-5 text-emerald-400" />
                  Evolução da Movimentação
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={relatorioGerado.dadosGrafico}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="dia" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#0f172a', 
                        border: '1px solid #10b981',
                        borderRadius: '8px'
                      }} 
                    />
                    <Legend />
                    <Line type="monotone" dataKey="distancia" stroke="#10b981" strokeWidth={3} name="Distância (km)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={exportarPDF}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}