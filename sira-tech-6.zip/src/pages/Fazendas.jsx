import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Home, MapPin, Pencil } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import FazendaForm from "../components/fazendas/FazendaForm";
import { motion } from "framer-motion";

const HERO_IMAGE = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690180d00e5abc697ac29b36/7403cf153_13A15B9F-6918-4757-9E9D-B4AE5060FC0A.png";

export default function Fazendas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingFazenda, setEditingFazenda] = useState(null);

  const queryClient = useQueryClient();

  const { data: fazendas = [], isLoading } = useQuery({
    queryKey: ['fazendas'],
    queryFn: () => base44.entities.Fazenda.list('-created_date'),
    initialData: [],
  });

  const { data: animais = [] } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Fazenda.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fazendas'] });
      setShowForm(false);
      setEditingFazenda(null);
      alert('✅ Fazenda cadastrada com sucesso!');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Fazenda.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fazendas'] });
      setShowForm(false);
      setEditingFazenda(null);
      alert('✅ Fazenda atualizada com sucesso!');
    },
  });

  const handleSubmit = (data) => {
    if (editingFazenda) {
      updateMutation.mutate({ id: editingFazenda.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (fazenda) => {
    setEditingFazenda(fazenda);
    setShowForm(true);
  };

  const filteredFazendas = fazendas.filter(fazenda => {
    const matchesSearch = fazenda.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         fazenda.localizacao?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getAnimaisCount = (fazendaId) => {
    return animais.filter(a => a.fazenda_id === fazendaId).length;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      {/* Hero Section */}
      <div className="relative h-80 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/50 to-slate-950" />
        <img 
          src={HERO_IMAGE} 
          alt="Fazendas" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4 px-4">
            <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 40px rgba(0,255,65,0.4)'}}>
              Minhas Fazendas
            </h1>
            <p className="text-xl text-slate-300 font-semibold">
              Gerencie suas propriedades rurais
            </p>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-8">
        <div className="max-w-[1600px] mx-auto space-y-6">
          {/* Actions Bar */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" style={{boxShadow: '0 0 10px rgba(0,255,65,0.8)'}} />
              <p className="text-slate-400 font-medium">
                {fazendas.length} {fazendas.length === 1 ? 'fazenda cadastrada' : 'fazendas cadastradas'}
              </p>
            </div>
            <Button
              onClick={() => {
                setEditingFazenda(null);
                setShowForm(true);
              }}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
            >
              <Plus className="w-4 h-4 mr-2" />
              Cadastrar Fazenda
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
            <Input
              placeholder="Buscar por nome ou localização..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-950/50 border-slate-800 text-slate-200 placeholder:text-slate-500 focus:border-emerald-500"
            />
          </div>

          {/* Fazendas Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-64 bg-slate-900/50 animate-pulse rounded-xl border border-slate-800" />
              ))}
            </div>
          ) : filteredFazendas.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 bg-slate-900/50 rounded-full flex items-center justify-center border border-slate-800">
                <Home className="w-10 h-10 text-slate-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-400 mb-2">
                Nenhuma fazenda encontrada
              </h3>
              <p className="text-slate-600 mb-4">
                Cadastre sua primeira fazenda para começar
              </p>
              <Button
                onClick={() => {
                  setEditingFazenda(null);
                  setShowForm(true);
                }}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <Plus className="w-4 h-4 mr-2" />
                Cadastrar Primeira Fazenda
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredFazendas.map((fazenda) => (
                <motion.div
                  key={fazenda.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="overflow-hidden bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all duration-300 shadow-xl h-full">
                    <div className="relative h-32 bg-gradient-to-br from-emerald-950/30 via-slate-950 to-green-950/30">
                      <div className="w-full h-full flex items-center justify-center">
                        <Home className="w-16 h-16 text-emerald-500/30" />
                      </div>
                      <div className="absolute top-3 right-3">
                        <Badge className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 font-bold">
                          {fazenda.tipo_criacao || 'Não especificado'}
                        </Badge>
                      </div>
                    </div>

                    <CardContent className="p-4 space-y-3">
                      <div>
                        <h3 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                          {fazenda.nome}
                        </h3>
                        <div className="flex items-start gap-2 text-sm text-slate-400 mt-1">
                          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" />
                          <span className="line-clamp-2">{fazenda.localizacao}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-slate-500">Área</p>
                          <p className="font-medium text-slate-200">
                            {fazenda.area_hectares ? `${fazenda.area_hectares} ha` : '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-500">Animais</p>
                          <p className="font-medium text-emerald-400">
                            {getAnimaisCount(fazenda.id)}
                          </p>
                        </div>
                      </div>

                      {fazenda.responsavel && (
                        <div className="text-sm pt-2 border-t border-slate-800">
                          <p className="text-slate-500">Responsável</p>
                          <p className="font-medium text-slate-200">{fazenda.responsavel}</p>
                        </div>
                      )}

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(fazenda)}
                        className="w-full mt-2 bg-slate-900/50 border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/50 hover:border-emerald-400 font-bold"
                      >
                        <Pencil className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}

          {/* Info Card */}
          {fazendas.length > 0 && (
            <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                    <Home className="w-6 h-6 text-slate-950" />
                  </div>
                  <div>
                    <h3 className="font-black text-emerald-400 text-lg mb-2">💡 Dica Importante</h3>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      Cadastre suas fazendas antes de registrar animais. Isso permite um melhor controle e organização do seu rebanho por propriedade. 
                      Ao cadastrar um animal, você poderá associá-lo à fazenda correspondente.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Form Dialog */}
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-950 border-slate-800">
              <DialogHeader>
                <DialogTitle className="text-slate-200 font-black">
                  {editingFazenda ? 'Editar Fazenda' : 'Cadastrar Nova Fazenda'}
                </DialogTitle>
              </DialogHeader>
              <FazendaForm
                fazenda={editingFazenda}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingFazenda(null);
                }}
                isLoading={createMutation.isPending || updateMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}