import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Leaf, Download, FileText, Battery, Zap, Award } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

export default function RelatorioSustentabilidade() {
  const [periodoInicio, setPeriodoInicio] = useState('');
  const [periodoFim, setPeriodoFim] = useState('');
  const [relatorioGerado, setRelatorioGerado] = useState(null);

  const gerarRelatorio = () => {
    const dadosEnergia = [
      { name: 'Energia Solar', value: 85, color: '#10b981' },
      { name: 'Rede Elétrica', value: 15, color: '#64748b' },
    ];

    setRelatorioGerado({
      periodo: { inicio: periodoInicio, fim: periodoFim },
      energiaSolar: 1240,
      co2Evitado: 850,
      economiaFinanceira: 2340,
      certificacaoAtiva: true,
      dadosEnergia,
    });
  };

  const exportarPDF = () => {
    alert('Exportando relatório em PDF... (funcionalidade em desenvolvimento)');
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Relatório de Sustentabilidade
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Impacto ambiental e economia de energia
            </p>
          </div>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <FileText className="w-5 h-5 text-emerald-400" />
              Configurar Relatório
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Data Início</Label>
                <Input
                  type="date"
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Data Fim</Label>
                <Input
                  type="date"
                  value={periodoFim}
                  onChange={(e) => setPeriodoFim(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={gerarRelatorio}
                  className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  <Leaf className="w-4 h-4 mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {relatorioGerado && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Battery className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Energia Solar</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.energiaSolar} kWh
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Leaf className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">CO₂ Evitado</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.co2Evitado} kg
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Zap className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Economia</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        R$ {relatorioGerado.economiaFinanceira}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Award className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Certificação</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.certificacaoAtiva ? 'Ativa' : 'Pendente'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                  <Battery className="w-5 h-5 text-emerald-400" />
                  Distribuição de Energia
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <ResponsiveContainer width="100%" height={400}>
                  <PieChart>
                    <Pie
                      data={relatorioGerado.dadosEnergia}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {relatorioGerado.dadosEnergia.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#0f172a', 
                        border: '1px solid #10b981',
                        borderRadius: '8px'
                      }} 
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={exportarPDF}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}