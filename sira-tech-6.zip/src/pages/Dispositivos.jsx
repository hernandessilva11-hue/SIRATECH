
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Radio, WifiOff, Settings2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import DispositivoForm from "../components/dispositivos/DispositivoForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const statusColors = {
  'Ativo': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
  'Offline': 'bg-red-500/20 text-red-400 border-red-500/50',
  'Manutenção': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  'Inativo': 'bg-slate-500/20 text-slate-400 border-slate-500/50',
};

export default function Dispositivos() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingDispositivo, setEditingDispositivo] = useState(null);

  const queryClient = useQueryClient();

  const { data: dispositivos = [], isLoading } = useQuery({
    queryKey: ['dispositivos'],
    queryFn: () => base44.entities.Dispositivo.list('-created_date'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Dispositivo.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dispositivos'] });
      setShowForm(false);
      setEditingDispositivo(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Dispositivo.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dispositivos'] });
      setShowForm(false);
      setEditingDispositivo(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingDispositivo) {
      updateMutation.mutate({ id: editingDispositivo.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (dispositivo) => {
    setEditingDispositivo(dispositivo);
    setShowForm(true);
  };

  const filteredDispositivos = dispositivos.filter(dispositivo => {
    const matchesSearch = dispositivo.codigo?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || dispositivo.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const ativos = dispositivos.filter(d => d.status === 'Ativo').length;
  const offline = dispositivos.filter(d => d.status === 'Offline').length;

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Dispositivos IoT
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Gerencie sensores e equipamentos de rastreamento
            </p>
          </div>
          <Button
            onClick={() => {
              setEditingDispositivo(null);
              setShowForm(true);
            }}
            className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
          >
            <Plus className="w-4 h-4 mr-2" />
            Cadastrar Dispositivo
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Total de Dispositivos</CardTitle>
              <Radio className="w-4 h-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">{dispositivos.length}</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Ativos</CardTitle>
              <Radio className="w-4 h-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">{ativos}</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Offline</CardTitle>
              <WifiOff className="w-4 h-4 text-red-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-red-400">{offline}</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
            <Input
              placeholder="Buscar por código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-950/50 border-slate-800 text-slate-200 placeholder:text-slate-500"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-48 bg-slate-950/50 border-slate-800 text-slate-200">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800">
              <SelectItem value="all">Todos Status</SelectItem>
              <SelectItem value="Ativo">Ativo</SelectItem>
              <SelectItem value="Offline">Offline</SelectItem>
              <SelectItem value="Manutenção">Manutenção</SelectItem>
              <SelectItem value="Inativo">Inativo</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Dispositivos Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-56 bg-slate-900/50 animate-pulse rounded-xl border border-slate-800" />
            ))}
          </div>
        ) : filteredDispositivos.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-4 bg-slate-900/50 rounded-full flex items-center justify-center border border-slate-800">
              <Radio className="w-10 h-10 text-slate-500" />
            </div>
            <h3 className="text-xl font-semibold text-slate-300 mb-2">
              Nenhum dispositivo encontrado
            </h3>
            <p className="text-slate-500">
              Cadastre dispositivos para começar o rastreamento
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDispositivos.map((dispositivo) => (
              <Card key={dispositivo.id} className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/20 transition-all">
                <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Radio className="w-5 h-5 text-emerald-400" />
                      <CardTitle className="text-lg text-slate-200">{dispositivo.codigo}</CardTitle>
                    </div>
                    <Badge className={`${statusColors[dispositivo.status]} border`}>
                      {dispositivo.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-slate-500">Tipo</p>
                      <p className="font-medium text-slate-200">{dispositivo.tipo}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Comunicação</p>
                      <p className="font-medium text-slate-200">{dispositivo.tipo_comunicacao || '-'}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Bateria/Energia</span>
                      <span className="font-medium text-slate-200">{dispositivo.nivel_bateria || 0}%</span>
                    </div>
                    <Progress value={dispositivo.nivel_bateria || 0} className="h-2 bg-slate-800" />
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(dispositivo)}
                    className="w-full mt-2 bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-emerald-950/50 hover:text-emerald-400 hover:border-emerald-500/50"
                  >
                    <Settings2 className="w-4 h-4 mr-2" />
                    Configurar
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Form Dialog */}
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-950 border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-200 font-black">
                {editingDispositivo ? 'Editar Dispositivo' : 'Cadastrar Novo Dispositivo'}
              </DialogTitle>
            </DialogHeader>
            <DispositivoForm
              dispositivo={editingDispositivo}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingDispositivo(null);
              }}
              isLoading={createMutation.isPending || updateMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
