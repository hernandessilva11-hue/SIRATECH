
import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Radio, 
  AlertTriangle, 
  Leaf, 
  TrendingUp,
  MapPin,
  Activity,
  Battery,
  Zap
} from "lucide-react";
import StatsCard from "../components/dashboard/StatsCard";
import AlertsList from "../components/dashboard/AlertsList";
import MapView from "../components/dashboard/MapView";
import SustainabilityMetrics from "../components/dashboard/SustainabilityMetrics";
import SystemStatus from "../components/dashboard/SystemStatus";

export default function Dashboard() {
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: animais = [], isLoading: loadingAnimais } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const { data: dispositivos = [], isLoading: loadingDispositivos } = useQuery({
    queryKey: ['dispositivos'],
    queryFn: () => base44.entities.Dispositivo.list(),
    initialData: [],
  });

  const { data: alertas = [], isLoading: loadingAlertas } = useQuery({
    queryKey: ['alertas'],
    queryFn: () => base44.entities.Alerta.list('-created_date'),
    initialData: [],
  });

  const { data: fazendas = [] } = useQuery({
    queryKey: ['fazendas'],
    queryFn: () => base44.entities.Fazenda.list(),
    initialData: [],
  });

  const alertasAtivos = alertas.filter(a => a.status === 'Ativo');
  const dispositivosAtivos = dispositivos.filter(d => d.status === 'Ativo');
  const animaisRastreados = animais.filter(a => a.dispositivo_id);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Bom dia";
    if (hour < 18) return "Boa tarde";
    return "Boa noite";
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header com Saudação */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-500 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
                {getGreeting()}{user ? `, ${user.full_name.split(' ')[0]}` : ''}
              </h1>
            </div>
            <p className="text-slate-400 font-medium flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              Painel de Controle e Monitoramento - {fazendas.length} {fazendas.length === 1 ? 'fazenda' : 'fazendas'}
            </p>
          </div>
          <SystemStatus />
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Total de Animais"
            value={animais.length}
            icon={Activity}
            gradient="from-emerald-500 to-green-600"
            loading={loadingAnimais}
          />
          <StatsCard
            title="Dispositivos Ativos"
            value={dispositivosAtivos.length}
            subtitle={`de ${dispositivos.length} total`}
            icon={Radio}
            gradient="from-cyan-500 to-blue-600"
            loading={loadingDispositivos}
          />
          <StatsCard
            title="Alertas Ativos"
            value={alertasAtivos.length}
            icon={AlertTriangle}
            gradient="from-orange-500 to-red-600"
            loading={loadingAlertas}
          />
          <StatsCard
            title="Rastreamento GPS"
            value={animaisRastreados.length}
            subtitle="em tempo real"
            icon={MapPin}
            gradient="from-green-400 to-emerald-600"
            loading={loadingAnimais}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MapView animais={animaisRastreados} alertas={alertasAtivos} />
          </div>
          <div className="lg:col-span-1">
            <AlertsList alertas={alertasAtivos} loading={loadingAlertas} />
          </div>
        </div>

        <SustainabilityMetrics />
      </div>
    </div>
  );
}
