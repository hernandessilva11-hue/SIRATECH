import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Users, UserPlus, Mail, Shield, Trash2, Edit, Crown } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function GestaoEquipe() {
  const [user, setUser] = useState(null);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingMembro, setEditingMembro] = useState(null);
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    email_membro: '',
    nome_membro: '',
    papel: 'Operador',
    permissoes: {
      cadastrar_animais: true,
      editar_animais: true,
      excluir_animais: false,
      gerenciar_dispositivos: true,
      visualizar_relatorios: true,
      gerenciar_equipe: false
    }
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: membros = [] } = useQuery({
    queryKey: ['membros'],
    queryFn: () => base44.entities.MembroEquipe.list('-created_date'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MembroEquipe.create({
      ...data,
      organizacao_id: user?.email,
      status: 'Ativo'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['membros'] });
      setShowInviteDialog(false);
      resetForm();
      alert('✅ Membro convidado com sucesso!');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MembroEquipe.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['membros'] });
      setShowEditDialog(false);
      setEditingMembro(null);
      alert('✅ Membro atualizado com sucesso!');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MembroEquipe.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['membros'] });
      alert('✅ Membro removido com sucesso!');
    },
  });

  const resetForm = () => {
    setFormData({
      email_membro: '',
      nome_membro: '',
      papel: 'Operador',
      permissoes: {
        cadastrar_animais: true,
        editar_animais: true,
        excluir_animais: false,
        gerenciar_dispositivos: true,
        visualizar_relatorios: true,
        gerenciar_equipe: false
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleEdit = (membro) => {
    setEditingMembro(membro);
    setFormData({
      email_membro: membro.email_membro,
      nome_membro: membro.nome_membro,
      papel: membro.papel,
      permissoes: membro.permissoes || {
        cadastrar_animais: true,
        editar_animais: true,
        excluir_animais: false,
        gerenciar_dispositivos: true,
        visualizar_relatorios: true,
        gerenciar_equipe: false
      }
    });
    setShowEditDialog(true);
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    updateMutation.mutate({ id: editingMembro.id, data: formData });
  };

  const handleDelete = (id) => {
    if (confirm('Tem certeza que deseja remover este membro da equipe?')) {
      deleteMutation.mutate(id);
    }
  };

  const papelColors = {
    'Proprietário': 'bg-purple-500/20 text-purple-400 border-purple-500/50',
    'Administrador': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
    'Operador': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50',
    'Visualizador': 'bg-slate-500/20 text-slate-400 border-slate-500/50',
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Gestão de Equipe
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Gerencie os membros com acesso ao sistema
            </p>
          </div>
          <Button
            onClick={() => {
              resetForm();
              setShowInviteDialog(true);
            }}
            className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Convidar Membro
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                  <Users className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Total de Membros</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    {membros.length + 1}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                  <Shield className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Administradores</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    {membros.filter(m => m.papel === 'Administrador').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg">
                  <Users className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Operadores</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                    {membros.filter(m => m.papel === 'Operador').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-slate-500 to-slate-600 shadow-lg">
                  <Users className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Visualizadores</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-slate-400 to-slate-400">
                    {membros.filter(m => m.papel === 'Visualizador').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Owner Card */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-purple-500/30 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-purple-950/30 to-pink-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <Crown className="w-5 h-5 text-purple-400" />
              Proprietário da Conta
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center shadow-lg border-4 border-purple-400">
                  <span className="text-slate-950 font-black text-xl">
                    {user?.full_name?.[0]?.toUpperCase() || 'U'}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-200">{user?.full_name}</h3>
                  <p className="text-sm text-slate-400">{user?.email}</p>
                </div>
              </div>
              <Badge className={papelColors['Proprietário']} style={{padding: '8px 16px'}}>
                <Crown className="w-4 h-4 mr-2" />
                Proprietário
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Team Members */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <Users className="w-5 h-5 text-emerald-400" />
              Membros da Equipe
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {membros.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 mx-auto mb-4 bg-slate-900/50 rounded-full flex items-center justify-center border border-slate-800">
                  <Users className="w-10 h-10 text-slate-600" />
                </div>
                <h3 className="text-xl font-semibold text-slate-400 mb-2">
                  Nenhum membro na equipe
                </h3>
                <p className="text-slate-600 mb-4">
                  Convide membros para colaborar no sistema
                </p>
                <Button
                  onClick={() => setShowInviteDialog(true)}
                  className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Convidar Primeiro Membro
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {membros.map((membro) => (
                  <div
                    key={membro.id}
                    className="flex items-center justify-between p-4 bg-slate-900/50 rounded-xl border border-slate-800 hover:border-emerald-500/30 transition-all"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-slate-950 font-black">
                          {membro.nome_membro?.[0]?.toUpperCase() || membro.email_membro?.[0]?.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-slate-200">{membro.nome_membro}</h4>
                        <p className="text-sm text-slate-400 flex items-center gap-2">
                          <Mail className="w-3 h-3" />
                          {membro.email_membro}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className={papelColors[membro.papel]}>
                        {membro.papel}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(membro)}
                        className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/50"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(membro.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-950/50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                <Shield className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <h3 className="font-black text-emerald-400 text-lg mb-2">💡 Gestão Colaborativa</h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-2">
                  <strong>Proprietário:</strong> Você (dono da fazenda) - Acesso total e pode gerenciar equipe
                </p>
                <p className="text-sm text-slate-300 leading-relaxed mb-2">
                  <strong>Administrador:</strong> Gerencia operações diárias, cadastra animais e dispositivos
                </p>
                <p className="text-sm text-slate-300 leading-relaxed mb-2">
                  <strong>Operador:</strong> Cadastra e edita animais, gerencia dispositivos
                </p>
                <p className="text-sm text-slate-300 leading-relaxed">
                  <strong>Visualizador:</strong> Apenas visualiza dados e relatórios
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invite Dialog */}
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogContent className="max-w-2xl bg-slate-950 border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-200 font-black flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-400" />
                Convidar Novo Membro
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-emerald-400 font-bold">Email *</Label>
                  <Input
                    type="email"
                    value={formData.email_membro}
                    onChange={(e) => setFormData({...formData, email_membro: e.target.value})}
                    placeholder="email@exemplo.com"
                    required
                    className="bg-slate-900/50 border-slate-800 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-emerald-400 font-bold">Nome Completo *</Label>
                  <Input
                    value={formData.nome_membro}
                    onChange={(e) => setFormData({...formData, nome_membro: e.target.value})}
                    placeholder="João Silva"
                    required
                    className="bg-slate-900/50 border-slate-800 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-emerald-400 font-bold">Papel na Equipe</Label>
                <Select value={formData.papel} onValueChange={(value) => setFormData({...formData, papel: value})}>
                  <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-950 border-slate-800 text-white">
                    <SelectItem value="Administrador">Administrador</SelectItem>
                    <SelectItem value="Operador">Operador</SelectItem>
                    <SelectItem value="Visualizador">Visualizador</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <Label className="text-emerald-400 font-bold">Permissões</Label>
                {Object.entries({
                  cadastrar_animais: 'Cadastrar animais',
                  editar_animais: 'Editar animais',
                  excluir_animais: 'Excluir animais',
                  gerenciar_dispositivos: 'Gerenciar dispositivos',
                  visualizar_relatorios: 'Visualizar relatórios',
                  gerenciar_equipe: 'Gerenciar equipe'
                }).map(([key, label]) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-slate-300">{label}</span>
                    <Switch
                      checked={formData.permissoes[key]}
                      onCheckedChange={(checked) => setFormData({
                        ...formData,
                        permissoes: {...formData.permissoes, [key]: checked}
                      })}
                    />
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowInviteDialog(false)}
                  className="bg-slate-900/50 border-slate-800 text-slate-300"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  {createMutation.isPending ? 'Convidando...' : 'Convidar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-2xl bg-slate-950 border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-200 font-black flex items-center gap-2">
                <Edit className="w-5 h-5 text-emerald-400" />
                Editar Membro
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpdate} className="space-y-4 py-4">
              {/* Same form fields as invite */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-emerald-400 font-bold">Email</Label>
                  <Input
                    type="email"
                    value={formData.email_membro}
                    disabled
                    className="bg-slate-900/50 border-slate-800 text-slate-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-emerald-400 font-bold">Nome Completo</Label>
                  <Input
                    value={formData.nome_membro}
                    onChange={(e) => setFormData({...formData, nome_membro: e.target.value})}
                    className="bg-slate-900/50 border-slate-800 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-emerald-400 font-bold">Papel na Equipe</Label>
                <Select value={formData.papel} onValueChange={(value) => setFormData({...formData, papel: value})}>
                  <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-950 border-slate-800 text-white">
                    <SelectItem value="Administrador">Administrador</SelectItem>
                    <SelectItem value="Operador">Operador</SelectItem>
                    <SelectItem value="Visualizador">Visualizador</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <Label className="text-emerald-400 font-bold">Permissões</Label>
                {Object.entries({
                  cadastrar_animais: 'Cadastrar animais',
                  editar_animais: 'Editar animais',
                  excluir_animais: 'Excluir animais',
                  gerenciar_dispositivos: 'Gerenciar dispositivos',
                  visualizar_relatorios: 'Visualizar relatórios',
                  gerenciar_equipe: 'Gerenciar equipe'
                }).map(([key, label]) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-slate-300">{label}</span>
                    <Switch
                      checked={formData.permissoes[key]}
                      onCheckedChange={(checked) => setFormData({
                        ...formData,
                        permissoes: {...formData.permissoes, [key]: checked}
                      })}
                    />
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowEditDialog(false)}
                  className="bg-slate-900/50 border-slate-800 text-slate-300"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  {updateMutation.isPending ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}