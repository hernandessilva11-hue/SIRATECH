import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Activity, Download, FileText, Syringe, HeartPulse } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function RelatorioSaude() {
  const [periodoInicio, setPeriodoInicio] = useState('');
  const [periodoFim, setPeriodoFim] = useState('');
  const [relatorioGerado, setRelatorioGerado] = useState(null);

  const { data: animais = [] } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const gerarRelatorio = () => {
    const totalAnimais = animais.length;
    const animaisComVacinacao = animais.filter(a => a.vacinacoes && a.vacinacoes.length > 0).length;
    const coberturaVacinal = ((animaisComVacinacao / totalAnimais) * 100).toFixed(1);

    setRelatorioGerado({
      periodo: { inicio: periodoInicio, fim: periodoFim },
      totalAnimais,
      animaisComVacinacao,
      coberturaVacinal,
      animais,
    });
  };

  const exportarPDF = () => {
    alert('Exportando relatório em PDF... (funcionalidade em desenvolvimento)');
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Relatório de Saúde
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Controle sanitário e vacinação do rebanho
            </p>
          </div>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <FileText className="w-5 h-5 text-emerald-400" />
              Configurar Relatório
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Data Início</Label>
                <Input
                  type="date"
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Data Fim</Label>
                <Input
                  type="date"
                  value={periodoFim}
                  onChange={(e) => setPeriodoFim(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={gerarRelatorio}
                  className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  <Activity className="w-4 h-4 mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {relatorioGerado && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <HeartPulse className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Total de Animais</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.totalAnimais}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Syringe className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Com Vacinação</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.animaisComVacinacao}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <Activity className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Cobertura</p>
                      <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.coberturaVacinal}%
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                  <Syringe className="w-5 h-5 text-emerald-400" />
                  Status Sanitário do Rebanho
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  {relatorioGerado.animais.slice(0, 10).map((animal) => (
                    <div key={animal.id} className="p-4 border border-slate-800 rounded-xl bg-slate-900/50 flex items-center justify-between">
                      <div>
                        <p className="font-bold text-slate-200">{animal.nome || animal.id_eletronico}</p>
                        <p className="text-sm text-slate-500">Espécie: {animal.especie}</p>
                      </div>
                      <Badge className={animal.vacinacoes && animal.vacinacoes.length > 0 
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50' 
                        : 'bg-orange-500/20 text-orange-400 border-orange-500/50'
                      }>
                        {animal.vacinacoes && animal.vacinacoes.length > 0 ? 'Vacinado' : 'Pendente'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={exportarPDF}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}