
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Info, Target, Eye, Heart, Users, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

const LOGO_SIRA = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690180d00e5abc697ac29b36/8f5adb738_9F04B826-60A9-46FE-9302-C05424F7FF57.PNG";

export default function Sobre() {
  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1200px] mx-auto space-y-6">
        {/* Hero */}
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <img 
              src={LOGO_SIRA} 
              alt="SIRA-TECH Logo" 
              className="w-48 h-48 object-contain drop-shadow-2xl"
              style={{filter: 'drop-shadow(0 0 40px rgba(0,255,65,0.4))'}}
            />
          </div>
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400 mb-2" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Sobre o SIRA-TECH
            </h1>
            <p className="text-slate-400 font-medium">
              Inovação e Sustentabilidade na Pecuária
            </p>
          </div>
        </div>

        {/* Missão, Visão e Valores */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 border-b border-emerald-900/30">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black text-base">
                <Target className="w-5 h-5 text-emerald-400" />
                Missão
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-300 leading-relaxed">
                Revolucionar a pecuária com tecnologia sustentável e acessível, promovendo eficiência e bem-estar animal.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 border-b border-emerald-900/30">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black text-base">
                <Eye className="w-5 h-5 text-emerald-400" />
                Visão
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-300 leading-relaxed">
                Ser referência em IoT para agropecuária, promovendo eficiência e sustentabilidade no setor.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 border-b border-emerald-900/30">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black text-base">
                <Heart className="w-5 h-5 text-emerald-400" />
                Valores
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-300 leading-relaxed">
                Inovação, Sustentabilidade, Transparência e Compromisso com o Produtor Rural.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* O que é o SIRA-TECH */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <Info className="w-5 h-5 text-emerald-400" />
              O Projeto
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <p className="text-slate-300 leading-relaxed">
              O <strong className="text-emerald-400">SIRA-TECH</strong> (Sistema Integrado de Rastreamento e Análise com Tecnologia) 
              é uma solução inovadora de IoT que combina sensores inteligentes, energia solar e software avançado 
              para monitorar rebanhos em tempo real.
            </p>
            <p className="text-slate-300 leading-relaxed">
              Nossa plataforma oferece rastreamento GPS, monitoramento de saúde, alertas automáticos e análises 
              detalhadas de desempenho, tudo com foco em sustentabilidade e eficiência operacional.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-emerald-400 font-black">✓</span>
                </div>
                <div>
                  <p className="font-bold text-slate-200 text-sm">Tecnologia IoT Avançada</p>
                  <p className="text-xs text-slate-500">Sensores e GPS em tempo real</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-emerald-400 font-black">✓</span>
                </div>
                <div>
                  <p className="font-bold text-slate-200 text-sm">Energia 100% Solar</p>
                  <p className="text-xs text-slate-500">Sustentabilidade e economia</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-emerald-400 font-black">✓</span>
                </div>
                <div>
                  <p className="font-bold text-slate-200 text-sm">Análises Inteligentes</p>
                  <p className="text-xs text-slate-500">Relatórios e insights automáticos</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className="w-8 h-8 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-emerald-400 font-black">✓</span>
                </div>
                <div>
                  <p className="font-bold text-slate-200 text-sm">Bem-estar Animal</p>
                  <p className="text-xs text-slate-500">Monitoramento de saúde 24/7</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Site Oficial */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                  <ExternalLink className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <h3 className="font-black text-emerald-400 text-lg">Visite Nosso Site Oficial</h3>
                  <p className="text-sm text-slate-400">Saiba mais sobre o SIRA-TECH</p>
                </div>
              </div>
              <Button
                onClick={() => window.open('https://www.siratechbrasil.com.br', '_blank')}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                www.siratechbrasil.com.br
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
