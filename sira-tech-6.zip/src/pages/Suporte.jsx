import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { HelpCircle, MessageCircle, Book, Mail, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ChatIA from "../components/suporte/ChatIA";

const LOGO_SIRA = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690180d00e5abc697ac29b36/8f5adb738_9F04B826-60A9-46FE-9302-C05424F7FF57.PNG";

export default function Suporte() {
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1200px] mx-auto space-y-6">
        {/* Hero Section with Logo */}
        <div className="text-center space-y-6 mb-8">
          <div className="flex justify-center">
            <img 
              src={LOGO_SIRA} 
              alt="SIRA-TECH Logo" 
              className="w-64 h-64 object-contain drop-shadow-2xl"
              style={{filter: 'drop-shadow(0 0 40px rgba(0,255,65,0.4))'}}
            />
          </div>
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400 mb-2" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Central de Suporte SIRA-TECH
            </h1>
            <p className="text-slate-400 font-medium">
              Estamos aqui para ajudar você 24 horas por dia
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all shadow-xl">
            <CardHeader className="bg-gradient-to-r from-blue-950/30 to-cyan-950/30 border-b border-slate-800/50">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                <MessageCircle className="w-5 h-5 text-cyan-400" />
                Chat com IA
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-400 mb-4">
                Tire dúvidas sobre sensores, rastreamento e funcionalidades
              </p>
              <Button 
                onClick={() => setShowChat(true)}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 shadow-lg shadow-cyan-500/50 font-bold"
              >
                Iniciar Chat
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all shadow-xl">
            <CardHeader className="bg-gradient-to-r from-green-950/30 to-emerald-950/30 border-b border-slate-800/50">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                <Book className="w-5 h-5 text-emerald-400" />
                Base de Conhecimento
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-400 mb-4">
                Acesse tutoriais e guias de uso do sistema
              </p>
              <Button variant="outline" className="w-full bg-slate-900/50 border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/50 font-bold">
                Ver Documentação
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 md:col-span-2 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-purple-950/30 to-pink-950/30 border-b border-slate-800/50">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                <Mail className="w-5 h-5 text-purple-400" />
                Contato Direto
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-slate-400 mb-4">
                Entre em contato com nossa equipe técnica
              </p>
              <div className="space-y-3 text-slate-300">
                <div className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                  <Mail className="w-5 h-5 text-emerald-400" />
                  <div>
                    <p className="text-xs text-slate-500 font-semibold uppercase">Email</p>
                    <p className="text-sm font-bold text-emerald-400">suporte@siratechbrasil.com.br</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                  <Phone className="w-5 h-5 text-emerald-400" />
                  <div>
                    <p className="text-xs text-slate-500 font-semibold uppercase">Telefone</p>
                    <p className="text-sm font-bold text-emerald-400">(15) 99178-6976</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-emerald-950/30 rounded-lg border border-emerald-500/30">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" style={{boxShadow: '0 0 10px rgba(0,255,65,0.8)'}} />
                  <div>
                    <p className="text-xs text-slate-500 font-semibold uppercase">Horário de Atendimento</p>
                    <p className="text-sm font-bold text-emerald-400">24 horas - Todos os dias</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 flex items-center justify-center bg-gradient-to-br from-emerald-950/50 to-green-950/50">
              <img 
                src={LOGO_SIRA} 
                alt="SIRA Logo" 
                className="w-48 h-48 object-contain drop-shadow-2xl"
                style={{filter: 'drop-shadow(0 0 40px rgba(0,255,65,0.5))'}}
              />
            </div>
            <CardContent className="p-6 flex items-center">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                    <HelpCircle className="w-6 h-6 text-slate-950" />
                  </div>
                  <div>
                    <h3 className="font-black text-emerald-400 text-xl mb-2">Sobre o SIRA-TECH</h3>
                    <p className="text-sm text-slate-300 leading-relaxed mb-2">
                      <strong className="text-emerald-400">Missão:</strong> Revolucionar a pecuária com tecnologia sustentável e acessível.
                    </p>
                    <p className="text-sm text-slate-300 leading-relaxed mb-2">
                      <strong className="text-emerald-400">Visão:</strong> Ser referência em IoT para agropecuária, promovendo eficiência e sustentabilidade.
                    </p>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      <strong className="text-emerald-400">Valores:</strong> Inovação, Sustentabilidade, Transparência e Compromisso com o Produtor Rural.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </div>
        </Card>
      </div>

      {/* Chat Dialog */}
      <Dialog open={showChat} onOpenChange={setShowChat}>
        <DialogContent className="max-w-3xl max-h-[90vh] p-0 bg-transparent border-0">
          <ChatIA onClose={() => setShowChat(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}