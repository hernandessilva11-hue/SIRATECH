import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Animais from "./Animais";

import Dispositivos from "./Dispositivos";

import Relatorios from "./Relatorios";

import Configuracoes from "./Configuracoes";

import Suporte from "./Suporte";

import RelatorioDesempenho from "./RelatorioDesempenho";

import RelatorioSustentabilidade from "./RelatorioSustentabilidade";

import RelatorioSaude from "./RelatorioSaude";

import RelatorioMovimentacao from "./RelatorioMovimentacao";

import RelatorioFinanceiro from "./RelatorioFinanceiro";

import Mapa from "./Mapa";

import CadastrarAnimal from "./CadastrarAnimal";

import Sustentabilidade from "./Sustentabilidade";

import Perfil from "./Perfil";

import Sobre from "./Sobre";

import Fazendas from "./Fazendas";

import GestaoEquipe from "./GestaoEquipe";

import PoliticaPrivacidade from "./PoliticaPrivacidade";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Animais: Animais,
    
    Dispositivos: Dispositivos,
    
    Relatorios: Relatorios,
    
    Configuracoes: Configuracoes,
    
    Suporte: Suporte,
    
    RelatorioDesempenho: RelatorioDesempenho,
    
    RelatorioSustentabilidade: RelatorioSustentabilidade,
    
    RelatorioSaude: RelatorioSaude,
    
    RelatorioMovimentacao: RelatorioMovimentacao,
    
    RelatorioFinanceiro: RelatorioFinanceiro,
    
    Mapa: Mapa,
    
    CadastrarAnimal: CadastrarAnimal,
    
    Sustentabilidade: Sustentabilidade,
    
    Perfil: Perfil,
    
    Sobre: Sobre,
    
    Fazendas: Fazendas,
    
    GestaoEquipe: GestaoEquipe,
    
    PoliticaPrivacidade: PoliticaPrivacidade,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Animais" element={<Animais />} />
                
                <Route path="/Dispositivos" element={<Dispositivos />} />
                
                <Route path="/Relatorios" element={<Relatorios />} />
                
                <Route path="/Configuracoes" element={<Configuracoes />} />
                
                <Route path="/Suporte" element={<Suporte />} />
                
                <Route path="/RelatorioDesempenho" element={<RelatorioDesempenho />} />
                
                <Route path="/RelatorioSustentabilidade" element={<RelatorioSustentabilidade />} />
                
                <Route path="/RelatorioSaude" element={<RelatorioSaude />} />
                
                <Route path="/RelatorioMovimentacao" element={<RelatorioMovimentacao />} />
                
                <Route path="/RelatorioFinanceiro" element={<RelatorioFinanceiro />} />
                
                <Route path="/Mapa" element={<Mapa />} />
                
                <Route path="/CadastrarAnimal" element={<CadastrarAnimal />} />
                
                <Route path="/Sustentabilidade" element={<Sustentabilidade />} />
                
                <Route path="/Perfil" element={<Perfil />} />
                
                <Route path="/Sobre" element={<Sobre />} />
                
                <Route path="/Fazendas" element={<Fazendas />} />
                
                <Route path="/GestaoEquipe" element={<GestaoEquipe />} />
                
                <Route path="/PoliticaPrivacidade" element={<PoliticaPrivacidade />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}