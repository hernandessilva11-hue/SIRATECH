
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { FileText, TrendingUp, Leaf, Activity, MapPin, DollarSign, ArrowRight } from "lucide-react";

export default function Relatorios() {
  const relatorios = [
    {
      titulo: "Desempenho do Rebanho",
      descricao: "Análise completa de ganho de peso, produtividade e crescimento do rebanho",
      icon: TrendingUp,
      page: "RelatorioDesempenho",
    },
    {
      titulo: "Sustentabilidade",
      descricao: "Impacto ambiental, economia de energia solar e redução de emissões de CO₂",
      icon: Leaf,
      page: "RelatorioSustentabilidade",
    },
    {
      titulo: "Saúde e Vacinação",
      descricao: "Histórico sanitário, vacinações aplicadas e controle de saúde do rebanho",
      icon: Activity,
      page: "RelatorioSaude",
    },
    {
      titulo: "Movimentação GPS",
      descricao: "Rastreamento, distâncias percorridas e padrões de movimentação dos animais",
      icon: MapPin,
      page: "RelatorioMovimentacao",
    },
    {
      titulo: "Financeiro",
      descricao: "Custos operacionais, investimentos em tecnologia e retorno sobre investimento",
      icon: DollarSign,
      page: "RelatorioFinanceiro",
    },
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-500 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Relatórios e Análises
          </h1>
          <p className="text-slate-400 mt-2 font-medium flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            Gere relatórios detalhados do seu sistema
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {relatorios.map((relatorio, index) => {
            const IconComponent = relatorio.icon;
            return (
              <Link key={index} to={createPageUrl(relatorio.page)}>
                <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all duration-300 shadow-xl hover:shadow-emerald-500/20 h-full cursor-pointer group">
                  <CardHeader className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 relative overflow-hidden border-b border-emerald-900/30">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
                    <div className="relative z-10 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-3 bg-emerald-500/20 rounded-xl backdrop-blur-sm border border-emerald-500/30">
                          <IconComponent className="w-6 h-6 text-emerald-400" />
                        </div>
                        <CardTitle className="text-lg font-black text-emerald-400">
                          {relatorio.titulo}
                        </CardTitle>
                      </div>
                      <ArrowRight className="w-5 h-5 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <p className="text-sm text-slate-400 leading-relaxed">
                      {relatorio.descricao}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold">
                      <FileText className="w-4 h-4" />
                      Clique para acessar
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {/* Info Card */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                <FileText className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <h3 className="font-black text-emerald-400 text-lg mb-2">Sistema de Relatórios Inteligente</h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Gere relatórios personalizados com dados em tempo real. Escolha o período desejado, 
                  visualize gráficos interativos e exporte em PDF ou Excel para análises mais detalhadas.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
