import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DollarSign, Download, FileText, TrendingUp, TrendingDown } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function RelatorioFinanceiro() {
  const [periodoInicio, setPeriodoInicio] = useState('');
  const [periodoFim, setPeriodoFim] = useState('');
  const [relatorioGerado, setRelatorioGerado] = useState(null);

  const gerarRelatorio = () => {
    const investimentoTotal = 45000;
    const custosOperacionais = 8500;
    const economiaEnergia = 2340;
    const roi = ((economiaEnergia * 12 - custosOperacionais) / investimentoTotal * 100).toFixed(1);

    const dadosGrafico = [
      { categoria: 'Investimento IoT', valor: 45000, tipo: 'despesa' },
      { categoria: 'Custos Operacionais', valor: 8500, tipo: 'despesa' },
      { categoria: 'Economia Energia', valor: 28080, tipo: 'receita' },
      { categoria: 'ROI Estimado', valor: 19580, tipo: 'receita' },
    ];

    setRelatorioGerado({
      periodo: { inicio: periodoInicio, fim: periodoFim },
      investimentoTotal,
      custosOperacionais,
      economiaEnergia,
      roi,
      dadosGrafico,
    });
  };

  const exportarPDF = () => {
    alert('Exportando relatório em PDF... (funcionalidade em desenvolvimento)');
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              Relatório Financeiro
            </h1>
            <p className="text-slate-400 mt-2 font-medium">
              Análise de custos e retorno sobre investimento
            </p>
          </div>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <FileText className="w-5 h-5 text-emerald-400" />
              Configurar Relatório
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Data Início</Label>
                <Input
                  type="date"
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Data Fim</Label>
                <Input
                  type="date"
                  value={periodoFim}
                  onChange={(e) => setPeriodoFim(e.target.value)}
                  className="bg-slate-900/50 border-slate-800 text-slate-200"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={gerarRelatorio}
                  className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Gerar Relatório
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {relatorioGerado && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <TrendingDown className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Investimento</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        R$ {relatorioGerado.investimentoTotal.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <DollarSign className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Custos Operacionais</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        R$ {relatorioGerado.custosOperacionais.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <TrendingUp className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">Economia Energia</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        R$ {relatorioGerado.economiaEnergia.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                      <TrendingUp className="w-6 h-6 text-slate-950" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-bold uppercase">ROI Anual</p>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                        {relatorioGerado.roi}%
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                  <DollarSign className="w-5 h-5 text-emerald-400" />
                  Análise Financeira
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={relatorioGerado.dadosGrafico}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="categoria" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#0f172a', 
                        border: '1px solid #10b981',
                        borderRadius: '8px'
                      }} 
                    />
                    <Legend />
                    <Bar dataKey="valor" fill="#10b981" name="Valor (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={exportarPDF}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}