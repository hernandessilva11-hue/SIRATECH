
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { PlusCircle } from "lucide-react";
import AnimalForm from "../components/animais/AnimalForm";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CadastrarAnimal() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Animal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animais'] });
      alert('Animal cadastrado com sucesso!');
      navigate(createPageUrl('Animais'));
    },
  });

  const handleSubmit = (data) => {
    createMutation.mutate(data);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1200px] mx-auto space-y-6">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Cadastrar Novo Animal
          </h1>
          <p className="text-slate-400 mt-2 font-medium">
            Adicione um novo animal ao sistema de rastreamento
          </p>
        </div>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <PlusCircle className="w-5 h-5 text-emerald-400" />
              Formulário de Cadastro
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <AnimalForm
              onSubmit={handleSubmit}
              onCancel={() => navigate(createPageUrl('Animais'))}
              isLoading={createMutation.isPending}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
