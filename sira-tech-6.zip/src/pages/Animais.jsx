
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AnimalCard from "../components/animais/AnimalCard";
import AnimalForm from "../components/animais/AnimalForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const HERO_IMAGE = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690180d00e5abc697ac29b36/7403cf153_13A15B9F-6918-4757-9E9D-B4AE5060FC0A.png";

export default function Animais() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [especieFilter, setEspecieFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingAnimal, setEditingAnimal] = useState(null);

  const queryClient = useQueryClient();

  const { data: animais = [], isLoading } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list('-created_date'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Animal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animais'] });
      setShowForm(false);
      setEditingAnimal(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Animal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animais'] });
      setShowForm(false);
      setEditingAnimal(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingAnimal) {
      updateMutation.mutate({ id: editingAnimal.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (animal) => {
    setEditingAnimal(animal);
    setShowForm(true);
  };

  const filteredAnimais = animais.filter(animal => {
    const matchesSearch = animal.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         animal.id_eletronico?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || animal.status === statusFilter;
    const matchesEspecie = especieFilter === "all" || animal.especie === especieFilter;
    return matchesSearch && matchesStatus && matchesEspecie;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      {/* Hero Section with Image */}
      <div className="relative h-80 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/50 to-slate-950" />
        <img 
          src={HERO_IMAGE} 
          alt="Animais no pasto" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4 px-4">
            <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 40px rgba(0,255,65,0.4)'}}>
              Gestão de Animais
            </h1>
            <p className="text-xl text-slate-300 font-semibold">
              Monitoramento inteligente do seu rebanho
            </p>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-8">
        <div className="max-w-[1600px] mx-auto space-y-6">
          {/* Actions Bar */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" style={{boxShadow: '0 0 10px rgba(0,255,65,0.8)'}} />
              <p className="text-slate-400 font-medium">
                {animais.length} animais cadastrados
              </p>
            </div>
            <Button
              onClick={() => {
                setEditingAnimal(null);
                setShowForm(true);
              }}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
            >
              <Plus className="w-4 h-4 mr-2" />
              Cadastrar Animal
            </Button>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
              <Input
                placeholder="Buscar por nome ou ID eletrônico..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-950/50 border-slate-800 text-slate-200 placeholder:text-slate-500 focus:border-emerald-500"
              />
            </div>
            <Select value={especieFilter} onValueChange={setEspecieFilter}>
              <SelectTrigger className="w-full md:w-48 bg-slate-950/50 border-slate-800 text-slate-200">
                <SelectValue placeholder="Espécie" />
              </SelectTrigger>
              <SelectContent className="bg-slate-950 border-slate-800">
                <SelectItem value="all">Todas Espécies</SelectItem>
                <SelectItem value="Bovino">Bovino</SelectItem>
                <SelectItem value="Ovino">Ovino</SelectItem>
                <SelectItem value="Caprino">Caprino</SelectItem>
                <SelectItem value="Suíno">Suíno</SelectItem>
                <SelectItem value="Equino">Equino</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48 bg-slate-950/50 border-slate-800 text-slate-200">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-slate-950 border-slate-800">
                <SelectItem value="all">Todos Status</SelectItem>
                <SelectItem value="Em pasto">Em pasto</SelectItem>
                <SelectItem value="Confinamento">Confinamento</SelectItem>
                <SelectItem value="Em trânsito">Em trânsito</SelectItem>
                <SelectItem value="Vendido">Vendido</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Animals Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-64 bg-slate-900/50 animate-pulse rounded-xl border border-slate-800" />
              ))}
            </div>
          ) : filteredAnimais.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-4 bg-slate-900/50 rounded-full flex items-center justify-center border border-slate-800">
                <Search className="w-10 h-10 text-slate-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-400 mb-2">
                Nenhum animal encontrado
              </h3>
              <p className="text-slate-600">
                Tente ajustar os filtros ou cadastre um novo animal
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAnimais.map((animal) => (
                <AnimalCard
                  key={animal.id}
                  animal={animal}
                  onEdit={handleEdit}
                />
              ))}
            </div>
          )}

          {/* Form Dialog */}
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-950 border-slate-800">
              <DialogHeader>
                <DialogTitle className="text-slate-200 font-black">
                  {editingAnimal ? 'Editar Animal' : 'Cadastrar Novo Animal'}
                </DialogTitle>
              </DialogHeader>
              <AnimalForm
                animal={editingAnimal}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingAnimal(null);
                }}
                isLoading={createMutation.isPending || updateMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
