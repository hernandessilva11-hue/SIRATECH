
import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { MapPin, Navigation, Activity, Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Mapa() {
  const { data: animais = [] } = useQuery({
    queryKey: ['animais'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const { data: dispositivos = [] } = useQuery({
    queryKey: ['dispositivos'],
    queryFn: () => base44.entities.Dispositivo.list(),
    initialData: [],
  });

  const animaisRastreados = animais.filter(a => a.dispositivo_id);
  const dispositivosAtivos = dispositivos.filter(d => d.status === 'Ativo');

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Mapa de Rastreamento
          </h1>
          <p className="text-slate-400 mt-2 font-medium">
            Monitoramento em tempo real do rebanho
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                  <Activity className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Animais Rastreados</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    {animaisRastreados.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                  <Radio className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Dispositivos Ativos</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    {dispositivosAtivos.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg">
                  <MapPin className="w-6 h-6 text-slate-950" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-bold uppercase">Áreas Monitoradas</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    3
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <MapPin className="w-5 h-5 text-emerald-400" />
              Visualização em Tempo Real
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="relative bg-gradient-to-br from-slate-950 via-emerald-950/20 to-slate-950 rounded-2xl h-[600px] overflow-hidden border-2 border-emerald-500/20" style={{boxShadow: 'inset 0 0 60px rgba(0,255,65,0.1)'}}>
              {/* Grid pattern */}
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: 'linear-gradient(rgba(0,255,65,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,65,0.3) 1px, transparent 1px)',
                backgroundSize: '50px 50px'
              }}></div>
              
              {/* Radar effect */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-96 h-96 rounded-full border-2 border-emerald-500/30 animate-ping" style={{animationDuration: '3s'}}></div>
                <div className="absolute w-72 h-72 rounded-full border-2 border-emerald-500/40 animate-ping" style={{animationDuration: '2s'}}></div>
              </div>
              
              {/* Center content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center space-y-4 z-10">
                  <div className="relative">
                    <div className="w-24 h-24 mx-auto bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl animate-pulse border-4 border-emerald-400" style={{boxShadow: '0 0 60px rgba(0,255,65,0.6)'}}>
                      <Navigation className="w-12 h-12 text-slate-950" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 20px rgba(0,255,65,0.3)'}}>
                      {animaisRastreados.length} Animais em Monitoramento
                    </h3>
                    <p className="text-slate-400 font-semibold">
                      Sistema GPS em Tempo Real
                    </p>
                  </div>
                </div>
              </div>

              {/* Sample markers */}
              {animaisRastreados.slice(0, 8).map((animal, index) => (
                <div
                  key={animal.id}
                  className="absolute group cursor-pointer"
                  style={{
                    top: `${15 + (index * 10)}%`,
                    left: `${20 + (index * 8)}%`,
                  }}
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full shadow-2xl flex items-center justify-center transform hover:scale-125 transition-transform border-2 border-emerald-300 animate-pulse"
                    style={{
                      boxShadow: '0 0 30px rgba(0,255,65,0.8)',
                      animationDelay: `${index * 0.2}s`
                    }}
                  >
                    <MapPin className="w-5 h-5 text-slate-950" />
                  </div>
                  <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-slate-950/95 border border-emerald-500/50 rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    <p className="text-xs font-bold text-emerald-400">{animal.nome || animal.id_eletronico}</p>
                    <p className="text-xs text-slate-400">{animal.especie}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 justify-center">
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/50 rounded-full border border-slate-800">
                <div className="w-4 h-4 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full shadow-lg" style={{boxShadow: '0 0 10px rgba(0,255,65,0.6)'}} />
                <span className="text-sm text-slate-300 font-semibold">Animal rastreado</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/50 rounded-full border border-slate-800">
                <div className="w-4 h-4 bg-gradient-to-br from-orange-400 to-red-500 rounded-full shadow-lg" style={{boxShadow: '0 0 10px rgba(255,100,0,0.6)'}} />
                <span className="text-sm text-slate-300 font-semibold">Alerta ativo</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/50 rounded-full border border-slate-800">
                <div className="w-4 h-4 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full shadow-lg" style={{boxShadow: '0 0 10px rgba(34,211,238,0.6)'}} />
                <span className="text-sm text-slate-300 font-semibold">Cerca virtual</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
