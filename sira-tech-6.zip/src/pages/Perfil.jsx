import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Mail, Shield, AlertCircle, Crown, Lock, Settings } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Perfil() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        setLoading(false);
      } catch (error) {
        console.error("Error loading user:", error);
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  if (loading) {
    return (
      <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-emerald-500/20 rounded-full flex items-center justify-center animate-pulse">
              <User className="w-8 h-8 text-emerald-400" />
            </div>
            <p className="text-slate-400">Carregando perfil...</p>
          </div>
        </div>
      </div>
    );
  }

  const hasPassword = user?.has_password !== false;

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1200px] mx-auto space-y-6">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Meu Perfil
          </h1>
          <p className="text-slate-400 mt-2 font-medium">
            Suas informações pessoais e configurações de conta
          </p>
        </div>

        {!hasPassword && (
          <Alert className="bg-orange-950/50 border-orange-500/50">
            <AlertCircle className="h-4 w-4 text-orange-400" />
            <AlertDescription className="text-orange-300">
              <strong>Atenção!</strong> Você ainda não configurou uma senha forte para sua conta.{' '}
              <Link to={createPageUrl("Configuracoes")} className="underline font-bold hover:text-orange-200">
                Configure agora
              </Link>{' '}
              para maior segurança.
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
                <User className="w-5 h-5 text-emerald-400" />
                Informações Pessoais
              </CardTitle>
              <Badge className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/50">
                <Crown className="w-3 h-3 mr-1" />
                {user?.role === 'admin' ? 'Administrador' : 'Usuário'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/50 border-4 border-emerald-400">
                <span className="text-slate-950 font-black text-3xl">
                  {user?.full_name?.[0]?.toUpperCase() || 'U'}
                </span>
              </div>
              <div className="text-center md:text-left">
                <h2 className="text-2xl font-black text-slate-200">{user?.full_name || 'Usuário'}</h2>
                <p className="text-slate-400">{user?.email || ''}</p>
                <p className="text-xs text-emerald-400 mt-1">
                  Membro desde {user?.created_date ? new Date(user.created_date).toLocaleDateString('pt-BR') : '-'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-400 text-xs uppercase font-bold">Nome Completo</Label>
                <Input
                  value={user?.full_name || ''}
                  disabled
                  className="bg-slate-900/50 border-slate-800 text-slate-300"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400 text-xs uppercase font-bold">Email</Label>
                <Input
                  value={user?.email || ''}
                  disabled
                  className="bg-slate-900/50 border-slate-800 text-slate-300"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400 text-xs uppercase font-bold">Função</Label>
                <Input
                  value={user?.role === 'admin' ? 'Administrador do Sistema' : 'Usuário Padrão'}
                  disabled
                  className="bg-slate-900/50 border-slate-800 text-slate-300"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-400 text-xs uppercase font-bold">ID da Conta</Label>
                <Input
                  value={user?.id || '-'}
                  disabled
                  className="bg-slate-900/50 border-slate-800 text-slate-300 font-mono text-xs"
                />
              </div>
            </div>

            <div className="mt-6 p-4 bg-slate-900/50 border border-slate-800 rounded-lg">
              <p className="text-xs text-slate-500 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                Suas informações estão protegidas com criptografia de ponta a ponta
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
          <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
            <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
              <Shield className="w-5 h-5 text-emerald-400" />
              Segurança da Conta
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="p-4 border border-slate-800 rounded-lg bg-slate-900/30">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-emerald-400 mt-1" />
                <div className="flex-1">
                  <p className="font-medium text-slate-200 mb-1">Senha de Acesso</p>
                  <p className="text-sm text-slate-500 mb-3">
                    {hasPassword 
                      ? 'Sua senha está configurada e protegida. Recomendamos alterá-la periodicamente.'
                      : '⚠️ Você ainda não configurou uma senha forte para sua conta.'
                    }
                  </p>
                  <Link to={createPageUrl("Configuracoes")}>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className={`${
                        hasPassword 
                          ? 'bg-slate-900/50 border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/50'
                          : 'bg-orange-950/50 border-orange-500/50 text-orange-400 hover:bg-orange-900/50'
                      } font-bold`}
                    >
                      <Lock className="w-4 h-4 mr-2" />
                      {hasPassword ? 'Alterar Senha' : 'Configurar Senha Agora'}
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            <div className="p-4 border border-slate-800 rounded-lg bg-slate-900/30">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-cyan-400 mt-1" />
                <div>
                  <p className="font-medium text-slate-200 mb-1">Email de Recuperação</p>
                  <p className="text-sm text-slate-500 mb-2">
                    {user?.email || 'Não configurado'}
                  </p>
                  <p className="text-xs text-slate-600">
                    Use este email para recuperar acesso à sua conta
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 border border-slate-800 rounded-lg bg-emerald-950/30 border-emerald-500/30">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-emerald-400 mt-1" />
                <div>
                  <p className="font-medium text-emerald-400 mb-1">Autenticação Segura</p>
                  <p className="text-sm text-slate-400">
                    Sua conta está protegida com autenticação da plataforma Base44 e timeout automático de 30 minutos por inatividade.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Link to={createPageUrl("Configuracoes")}>
            <Button className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold">
              <Settings className="w-4 h-4 mr-2" />
              Ir para Configurações
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}