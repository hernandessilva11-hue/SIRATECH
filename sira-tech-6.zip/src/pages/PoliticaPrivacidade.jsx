import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Shield, Lock, Eye, FileText, Database, Users, AlertCircle, CheckCircle } from "lucide-react";

export default function PoliticaPrivacidade() {
  const sections = [
    {
      icon: FileText,
      title: "1. Introdução",
      content: "Esta Política de Privacidade descreve como o SIRA-TECH coleta, usa, armazena e protege suas informações pessoais. Ao utilizar nosso sistema, você concorda com as práticas descritas nesta política."
    },
    {
      icon: Database,
      title: "2. Dados Coletados",
      items: [
        "Informações de Conta: nome completo, email, função",
        "Dados de Fazendas: nome, localização, área, tipo de criação",
        "Dados de Animais: identificação eletrônica, espécie, raça, peso, histórico",
        "Dados de Dispositivos: códigos, status, localização GPS",
        "Logs de Acesso: datas, horários e ações realizadas no sistema"
      ]
    },
    {
      icon: Lock,
      title: "3. Como Usamos Seus Dados",
      items: [
        "Fornecer e manter o serviço de rastreamento e monitoramento",
        "Gerar relatórios de desempenho e sustentabilidade",
        "Enviar notificações e alertas importantes",
        "Melhorar a experiência do usuário e as funcionalidades",
        "Garantir a segurança e prevenir fraudes"
      ]
    },
    {
      icon: Shield,
      title: "4. Segurança dos Dados",
      content: "Implementamos medidas de segurança de nível empresarial:",
      items: [
        "Criptografia de ponta a ponta para todos os dados",
        "Row Level Security (RLS) - isolamento total entre usuários",
        "Autenticação segura via plataforma Base44",
        "Timeout automático de sessão (30 minutos de inatividade)",
        "Monitoramento contínuo de atividades suspeitas",
        "Backups automáticos e redundância de dados"
      ]
    },
    {
      icon: Users,
      title: "5. Compartilhamento de Dados",
      content: "Seus dados NÃO são compartilhados com terceiros, exceto:",
      items: [
        "Membros da equipe que você convidar explicitamente",
        "Quando exigido por lei ou ordem judicial",
        "Para proteger nossos direitos legais"
      ]
    },
    {
      icon: Eye,
      title: "6. Seus Direitos",
      content: "Você tem direito a:",
      items: [
        "Acessar todos os seus dados pessoais a qualquer momento",
        "Corrigir informações incorretas ou desatualizadas",
        "Solicitar a exclusão de sua conta e dados",
        "Exportar seus dados em formato legível",
        "Revogar consentimento para processamento de dados",
        "Receber cópia de todos os dados coletados"
      ]
    },
    {
      icon: AlertCircle,
      title: "7. Cookies e Tecnologias Similares",
      content: "Utilizamos cookies essenciais para:",
      items: [
        "Manter sua sessão ativa e segura",
        "Lembrar suas preferências de configuração",
        "Analisar o uso do sistema para melhorias"
      ]
    },
    {
      icon: Database,
      title: "8. Retenção de Dados",
      content: "Mantemos seus dados enquanto sua conta estiver ativa. Após a exclusão da conta, os dados são removidos permanentemente em até 30 dias, exceto quando a retenção for exigida por lei."
    },
    {
      icon: CheckCircle,
      title: "9. Conformidade Legal",
      content: "O SIRA-TECH está em conformidade com:",
      items: [
        "Lei Geral de Proteção de Dados (LGPD) - Brasil",
        "General Data Protection Regulation (GDPR) - União Europeia",
        "Melhores práticas internacionais de segurança"
      ]
    }
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950">
      <div className="max-w-[1200px] mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl" style={{boxShadow: '0 0 40px rgba(0,255,65,0.6)'}}>
              <Shield className="w-10 h-10 text-slate-950" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
            Política de Privacidade
          </h1>
          <p className="text-slate-400 font-medium max-w-2xl mx-auto">
            Última atualização: {new Date().toLocaleDateString('pt-BR')}
          </p>
        </div>

        {/* Important Notice */}
        <Card className="bg-emerald-950/30 border-emerald-500/50 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                <Lock className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <h3 className="font-black text-emerald-400 text-lg mb-2">🔒 Seu compromisso com a privacidade</h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  No SIRA-TECH, levamos sua privacidade a sério. Utilizamos tecnologia de ponta para garantir que seus dados 
                  estejam sempre protegidos e que você tenha controle total sobre suas informações. Implementamos isolamento 
                  completo entre usuários - seus dados são visíveis apenas para você e pessoas que você autorizar.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sections */}
        <div className="space-y-4">
          {sections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <Card key={index} className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
                <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
                  <CardTitle className="flex items-center gap-3 text-slate-200 font-black">
                    <div className="p-2 bg-emerald-500/20 rounded-lg">
                      <IconComponent className="w-5 h-5 text-emerald-400" />
                    </div>
                    {section.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  {section.content && (
                    <p className="text-slate-300 leading-relaxed mb-3">{section.content}</p>
                  )}
                  {section.items && (
                    <ul className="space-y-2">
                      {section.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3 text-slate-400">
                          <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Contact Section */}
        <Card className="bg-slate-950/80 backdrop-blur-sm border-emerald-500/20 shadow-xl">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
                <FileText className="w-8 h-8 text-slate-950" />
              </div>
              <div className="text-center md:text-left">
                <h3 className="font-black text-emerald-400 text-xl mb-2">Dúvidas sobre Privacidade?</h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-3">
                  Se você tiver qualquer dúvida sobre esta Política de Privacidade ou sobre como tratamos seus dados, 
                  entre em contato conosco:
                </p>
                <div className="flex flex-col md:flex-row gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                    <span className="text-slate-400">Email:</span>
                    <span className="text-emerald-400 font-bold">privacidade@siratechbrasil.com.br</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                    <span className="text-slate-400">Telefone:</span>
                    <span className="text-emerald-400 font-bold">(15) 99178-6976</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer Note */}
        <div className="text-center py-6">
          <p className="text-xs text-slate-500">
            Esta política pode ser atualizada periodicamente. Notificaremos você sobre mudanças significativas.
          </p>
        </div>
      </div>
    </div>
  );
}