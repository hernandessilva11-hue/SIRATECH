import { base44 } from './base44Client';


export const Fazenda = base44.entities.Fazenda;

export const Animal = base44.entities.Animal;

export const Dispositivo = base44.entities.Dispositivo;

export const Alerta = base44.entities.Alerta;

export const Relatorio = base44.entities.Relatorio;

export const MembroEquipe = base44.entities.MembroEquipe;



// auth sdk:
export const User = base44.auth;