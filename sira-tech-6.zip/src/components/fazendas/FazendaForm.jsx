import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function FazendaForm({ fazenda, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(fazenda || {
    nome: '',
    localizacao: '',
    area_hectares: '',
    responsavel: '',
    telefone: '',
    tipo_criacao: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="nome" className="text-emerald-400 font-bold">Nome da Fazenda *</Label>
          <Input
            id="nome"
            value={formData.nome}
            onChange={(e) => handleChange('nome', e.target.value)}
            placeholder="Ex: Fazenda Esperança"
            required
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="localizacao" className="text-emerald-400 font-bold">Localização *</Label>
          <Textarea
            id="localizacao"
            value={formData.localizacao}
            onChange={(e) => handleChange('localizacao', e.target.value)}
            placeholder="Ex: Rod. SP-123, Km 45, Zona Rural - Sorocaba/SP"
            required
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
            rows={2}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="area_hectares" className="text-emerald-400 font-bold">Área (hectares)</Label>
          <Input
            id="area_hectares"
            type="number"
            value={formData.area_hectares}
            onChange={(e) => handleChange('area_hectares', parseFloat(e.target.value))}
            placeholder="Ex: 150"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo_criacao" className="text-emerald-400 font-bold">Tipo de Criação</Label>
          <Select value={formData.tipo_criacao} onValueChange={(value) => handleChange('tipo_criacao', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" className="text-emerald-500/50" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Extensivo" className="text-white">Extensivo</SelectItem>
              <SelectItem value="Semi-intensivo" className="text-white">Semi-intensivo</SelectItem>
              <SelectItem value="Intensivo" className="text-white">Intensivo</SelectItem>
              <SelectItem value="Confinamento" className="text-white">Confinamento</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="responsavel" className="text-emerald-400 font-bold">Responsável</Label>
          <Input
            id="responsavel"
            value={formData.responsavel}
            onChange={(e) => handleChange('responsavel', e.target.value)}
            placeholder="Ex: João Silva"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="telefone" className="text-emerald-400 font-bold">Telefone</Label>
          <Input
            id="telefone"
            value={formData.telefone}
            onChange={(e) => handleChange('telefone', e.target.value)}
            placeholder="Ex: (15) 99999-9999"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading} className="bg-slate-900/50 border-slate-800 text-slate-300">
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={isLoading}
          className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
        >
          {isLoading ? 'Salvando...' : fazenda ? 'Atualizar' : 'Cadastrar'}
        </Button>
      </div>
    </form>
  );
}