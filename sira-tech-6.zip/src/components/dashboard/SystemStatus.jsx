import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Activity, Wifi, Clock, Database } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function SystemStatus() {
  const [status, setStatus] = useState({
    online: true,
    latency: 0,
    lastUpdate: new Date(),
    uptime: '99.9%',
  });

  useEffect(() => {
    // Simula verificação de latência
    const checkLatency = async () => {
      const start = Date.now();
      try {
        // Simula ping ao servidor
        await new Promise(resolve => setTimeout(resolve, Math.random() * 100 + 50));
        const latency = Date.now() - start;
        setStatus(prev => ({
          ...prev,
          online: true,
          latency,
          lastUpdate: new Date(),
        }));
      } catch (error) {
        setStatus(prev => ({
          ...prev,
          online: false,
        }));
      }
    };

    checkLatency();
    const interval = setInterval(checkLatency, 30000); // A cada 30 segundos

    return () => clearInterval(interval);
  }, []);

  const getLatencyColor = () => {
    if (status.latency < 100) return 'text-emerald-400';
    if (status.latency < 300) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getLatencyStatus = () => {
    if (status.latency < 100) return 'Excelente';
    if (status.latency < 300) return 'Bom';
    return 'Lento';
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Badge 
          className="bg-emerald-500 text-slate-950 px-6 py-2.5 text-sm font-black shadow-lg border-2 border-emerald-400 cursor-pointer hover:bg-emerald-400 transition-all" 
          style={{boxShadow: '0 0 20px rgba(0,255,65,0.5)'}}
        >
          <Activity className="w-4 h-4 mr-2 animate-pulse" />
          {status.online ? 'SISTEMA ONLINE' : 'SISTEMA OFFLINE'}
        </Badge>
      </PopoverTrigger>
      <PopoverContent className="w-80 bg-slate-950/95 border-emerald-500/50 backdrop-blur-xl">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-lg" style={{boxShadow: '0 0 20px rgba(0,255,65,0.5)'}}>
              <Activity className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h4 className="font-black text-emerald-400">Status do Sistema</h4>
              <p className="text-xs text-slate-500">Monitoramento em tempo real</p>
            </div>
          </div>

          {/* Status Cards */}
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
              <div className="flex items-center gap-2">
                <Wifi className={`w-4 h-4 ${status.online ? 'text-emerald-400' : 'text-red-400'}`} />
                <span className="text-sm font-semibold text-slate-300">Conexão</span>
              </div>
              <span className={`text-sm font-bold ${status.online ? 'text-emerald-400' : 'text-red-400'}`}>
                {status.online ? 'Online' : 'Offline'}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-semibold text-slate-300">Latência</span>
              </div>
              <div className="text-right">
                <span className={`text-sm font-bold ${getLatencyColor()}`}>
                  {status.latency}ms
                </span>
                <p className="text-xs text-slate-600">{getLatencyStatus()}</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-semibold text-slate-300">Uptime</span>
              </div>
              <span className="text-sm font-bold text-emerald-400">
                {status.uptime}
              </span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-orange-400" />
                <span className="text-sm font-semibold text-slate-300">Última Verificação</span>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {status.lastUpdate.toLocaleTimeString('pt-BR')}
              </span>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800">
            <p className="text-xs text-slate-600 text-center">
              Todos os serviços operando normalmente ✓
            </p>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}