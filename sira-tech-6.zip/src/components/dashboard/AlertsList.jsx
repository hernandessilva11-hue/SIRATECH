import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, AlertCircle, Info, XCircle } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";

const severityConfig = {
  'Crítica': { icon: XCircle, color: 'bg-red-500/20 text-red-400 border-red-500/50' },
  'Alta': { icon: AlertTriangle, color: 'bg-orange-500/20 text-orange-400 border-orange-500/50' },
  'Média': { icon: AlertCircle, color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' },
  'Baixa': { icon: Info, color: 'bg-blue-500/20 text-blue-400 border-blue-500/50' },
};

export default function AlertsList({ alertas, loading }) {
  if (loading) {
    return (
      <Card className="h-full bg-slate-950/80 border-slate-800/50">
        <CardHeader>
          <Skeleton className="h-6 w-32 bg-slate-800" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-20 w-full bg-slate-800" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
      <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-orange-950/30 to-red-950/30">
        <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
          <AlertTriangle className="w-5 h-5 text-orange-400" />
          Alertas em Tempo Real
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[500px]">
          <div className="p-4 space-y-3">
            {alertas.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 bg-emerald-950/50 rounded-full flex items-center justify-center border-2 border-emerald-500/50">
                  <AlertTriangle className="w-8 h-8 text-emerald-400" />
                </div>
                <p className="text-slate-300 font-bold">Nenhum alerta ativo</p>
                <p className="text-sm text-slate-500 mt-1">Sistema funcionando normalmente</p>
              </div>
            ) : (
              alertas.map((alerta) => {
                const config = severityConfig[alerta.severidade] || severityConfig['Baixa'];
                const IconComponent = config.icon;
                
                return (
                  <div
                    key={alerta.id}
                    className="p-4 border border-slate-800/50 rounded-xl bg-slate-950/50 hover:bg-slate-900/50 hover:border-emerald-500/30 transition-all duration-200 backdrop-blur-sm"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2.5 rounded-lg ${config.color} border`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <h4 className="font-bold text-slate-200 text-sm">{alerta.tipo}</h4>
                          <Badge variant="outline" className={`${config.color} border text-xs font-bold`}>
                            {alerta.severidade}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-400 mb-2">{alerta.mensagem}</p>
                        <p className="text-xs text-slate-600 font-mono">
                          {format(new Date(alerta.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}