import React from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

export default function StatsCard({ title, value, subtitle, icon: Icon, gradient, loading }) {
  if (loading) {
    return (
      <Card className="overflow-hidden bg-slate-950/50 border-slate-800">
        <CardHeader className="p-6">
          <Skeleton className="h-20 w-full bg-slate-800" />
        </CardHeader>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="relative overflow-hidden bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all duration-300 shadow-xl hover:shadow-emerald-500/20">
        <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-5`} />
        <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${gradient} opacity-10 rounded-full blur-2xl`} />
        
        <CardHeader className="p-6 relative z-10">
          <div className="flex justify-between items-start">
            <div className="space-y-3 flex-1">
              <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">{title}</p>
              <p className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 20px rgba(0,255,65,0.2)'}}>
                {value}
              </p>
              {subtitle && (
                <p className="text-xs text-emerald-400 font-semibold">{subtitle}</p>
              )}
            </div>
            <div className={`p-4 rounded-2xl bg-gradient-to-br ${gradient} shadow-2xl relative`} style={{boxShadow: '0 0 30px rgba(0,255,65,0.3)'}}>
              <Icon className="w-7 h-7 text-slate-950" />
            </div>
          </div>
        </CardHeader>
      </Card>
    </motion.div>
  );
}