import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { MapPin, Navigation, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function MapView({ animais, alertas }) {
  return (
    <Card className="h-full bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
      <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
        <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
          <MapPin className="w-5 h-5 text-emerald-400" />
          Rastreamento em Tempo Real
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="relative bg-gradient-to-br from-slate-950 via-emerald-950/20 to-slate-950 rounded-2xl h-[500px] overflow-hidden border-2 border-emerald-500/20" style={{boxShadow: 'inset 0 0 60px rgba(0,255,65,0.1)'}}>
          {/* Grid pattern */}
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: 'linear-gradient(rgba(0,255,65,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,65,0.3) 1px, transparent 1px)',
            backgroundSize: '50px 50px'
          }}></div>
          
          {/* Radar effect */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-64 h-64 rounded-full border-2 border-emerald-500/30 animate-ping" style={{animationDuration: '3s'}}></div>
            <div className="absolute w-48 h-48 rounded-full border-2 border-emerald-500/40 animate-ping" style={{animationDuration: '2s'}}></div>
          </div>
          
          {/* Center content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center space-y-4 z-10">
              <div className="relative">
                <div className="w-24 h-24 mx-auto bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl animate-pulse border-4 border-emerald-400" style={{boxShadow: '0 0 60px rgba(0,255,65,0.6)'}}>
                  <Navigation className="w-12 h-12 text-slate-950" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-emerald-400 rounded-full flex items-center justify-center animate-bounce">
                  <Zap className="w-5 h-5 text-slate-950" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400" style={{textShadow: '0 0 20px rgba(0,255,65,0.3)'}}>
                  {animais.length} Animais Rastreados
                </h3>
                <p className="text-slate-400 font-semibold">
                  Sistema GPS em Tempo Real
                </p>
                {alertas.length > 0 && (
                  <Badge className="bg-orange-500/20 text-orange-400 border border-orange-500/50 font-bold">
                    {alertas.length} alertas de localização
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Sample markers with neon effect */}
          {animais.slice(0, 5).map((animal, index) => (
            <div
              key={animal.id}
              className="absolute w-10 h-10 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full shadow-2xl flex items-center justify-center transform hover:scale-125 transition-transform cursor-pointer border-2 border-emerald-300 animate-pulse"
              style={{
                top: `${20 + index * 15}%`,
                left: `${15 + index * 12}%`,
                boxShadow: '0 0 30px rgba(0,255,65,0.8), 0 0 60px rgba(0,255,65,0.4)',
                animationDelay: `${index * 0.2}s`
              }}
            >
              <MapPin className="w-5 h-5 text-slate-950" />
            </div>
          ))}
        </div>

        {/* Map Legend */}
        <div className="mt-4 flex flex-wrap gap-4 justify-center">
          <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/50 rounded-full border border-slate-800">
            <div className="w-4 h-4 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full shadow-lg" style={{boxShadow: '0 0 10px rgba(0,255,65,0.6)'}} />
            <span className="text-sm text-slate-300 font-semibold">Animal rastreado</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/50 rounded-full border border-slate-800">
            <div className="w-4 h-4 bg-gradient-to-br from-orange-400 to-red-500 rounded-full shadow-lg" style={{boxShadow: '0 0 10px rgba(255,100,0,0.6)'}} />
            <span className="text-sm text-slate-300 font-semibold">Alerta ativo</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}