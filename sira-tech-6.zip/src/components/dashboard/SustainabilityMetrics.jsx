import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Leaf, Battery, TrendingUp, Award, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function SustainabilityMetrics() {
  const metrics = [
    {
      icon: Battery,
      label: "Energia Solar",
      value: "1,240 kWh",
      progress: 85,
      color: "from-yellow-500 to-orange-500",
      shadow: "rgba(251,191,36,0.4)"
    },
    {
      icon: Leaf,
      label: "CO₂ Evitado",
      value: "850 kg",
      progress: 78,
      color: "from-emerald-500 to-green-600",
      shadow: "rgba(0,255,65,0.4)"
    },
    {
      icon: TrendingUp,
      label: "Eficiência",
      value: "+35%",
      progress: 92,
      color: "from-cyan-500 to-blue-600",
      shadow: "rgba(34,211,238,0.4)"
    },
    {
      icon: Award,
      label: "Certificação",
      value: "Ativo",
      progress: 100,
      color: "from-purple-500 to-pink-600",
      shadow: "rgba(168,85,247,0.4)"
    },
  ];

  return (
    <Card className="bg-slate-950/80 backdrop-blur-sm border-slate-800/50 shadow-xl">
      <CardHeader className="border-b border-slate-800/50 bg-gradient-to-r from-emerald-950/30 to-green-950/30">
        <CardTitle className="flex items-center gap-2 text-slate-200 font-black">
          <Leaf className="w-5 h-5 text-emerald-400" />
          Métricas de Sustentabilidade
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <div key={index} className="space-y-3 p-4 bg-slate-900/50 rounded-xl border border-slate-800/50 hover:border-emerald-500/30 transition-all">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${metric.color} shadow-2xl`} style={{boxShadow: `0 0 30px ${metric.shadow}`}}>
                    <IconComponent className="w-6 h-6 text-slate-950" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{metric.label}</p>
                    <p className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">{metric.value}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Progress value={metric.progress} className="h-2 bg-slate-800" />
                  <div className="flex justify-between items-center">
                    <p className="text-xs text-slate-500 font-semibold">{metric.progress}% da meta</p>
                    <Zap className="w-3 h-3 text-emerald-400" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-6 bg-gradient-to-r from-emerald-950/50 to-green-950/50 rounded-xl border-2 border-emerald-500/20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 to-green-500/5" />
          <div className="relative z-10 flex items-start gap-4">
            <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{boxShadow: '0 0 30px rgba(0,255,65,0.6)'}}>
              <Leaf className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h3 className="font-black text-emerald-400 text-lg mb-2">Impacto Sustentável</h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                Com o <span className="font-bold text-emerald-400">SIRA-TECH</span>, sua fazenda está contribuindo ativamente para um futuro mais sustentável, 
                reduzindo o consumo de energia convencional e promovendo práticas de gestão inteligente com 
                <span className="font-bold text-emerald-400"> tecnologia solar avançada</span>.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}