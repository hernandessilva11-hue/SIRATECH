import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function DispositivoForm({ dispositivo, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(dispositivo || {
    codigo: '',
    tipo: '',
    status: 'Ativo',
    nivel_bateria: 100,
    tipo_energia: 'Solar',
    data_instalacao: '',
    tipo_comunicacao: '',
    animal_id: '',
    fazenda_id: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="codigo" className="text-emerald-400 font-bold">Código do Dispositivo *</Label>
          <Input
            id="codigo"
            value={formData.codigo}
            onChange={(e) => handleChange('codigo', e.target.value)}
            placeholder="Ex: GPS-001"
            required
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo" className="text-emerald-400 font-bold">Tipo de Dispositivo *</Label>
          <Select value={formData.tipo} onValueChange={(value) => handleChange('tipo', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="GPS Tracker">GPS Tracker</SelectItem>
              <SelectItem value="Sensor de Temperatura">Sensor de Temperatura</SelectItem>
              <SelectItem value="Sensor de Movimento">Sensor de Movimento</SelectItem>
              <SelectItem value="Coleira Inteligente">Coleira Inteligente</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status" className="text-emerald-400 font-bold">Status</Label>
          <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Ativo">Ativo</SelectItem>
              <SelectItem value="Offline">Offline</SelectItem>
              <SelectItem value="Manutenção">Manutenção</SelectItem>
              <SelectItem value="Inativo">Inativo</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="nivel_bateria" className="text-emerald-400 font-bold">Nível de Bateria (%)</Label>
          <Input
            id="nivel_bateria"
            type="number"
            min="0"
            max="100"
            value={formData.nivel_bateria}
            onChange={(e) => handleChange('nivel_bateria', parseInt(e.target.value))}
            className="bg-slate-900/50 border-slate-800 text-white"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo_energia" className="text-emerald-400 font-bold">Tipo de Energia</Label>
          <Select value={formData.tipo_energia} onValueChange={(value) => handleChange('tipo_energia', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Solar">Solar</SelectItem>
              <SelectItem value="Bateria Recarregável">Bateria Recarregável</SelectItem>
              <SelectItem value="Híbrido">Híbrido</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo_comunicacao" className="text-emerald-400 font-bold">Tipo de Comunicação</Label>
          <Select value={formData.tipo_comunicacao} onValueChange={(value) => handleChange('tipo_comunicacao', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="LoRa">LoRa</SelectItem>
              <SelectItem value="Wi-Fi">Wi-Fi</SelectItem>
              <SelectItem value="4G">4G</SelectItem>
              <SelectItem value="Satélite">Satélite</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="data_instalacao" className="text-emerald-400 font-bold">Data de Instalação</Label>
          <Input
            id="data_instalacao"
            type="date"
            value={formData.data_instalacao}
            onChange={(e) => handleChange('data_instalacao', e.target.value)}
            className="bg-slate-900/50 border-slate-800 text-white"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading} className="bg-slate-900/50 border-slate-800 text-slate-300">
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={isLoading}
          className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
        >
          {isLoading ? 'Salvando...' : dispositivo ? 'Atualizar' : 'Cadastrar'}
        </Button>
      </div>
    </form>
  );
}