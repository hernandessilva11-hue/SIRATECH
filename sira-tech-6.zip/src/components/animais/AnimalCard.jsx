import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, MapPin, Calendar, Weight, Pencil } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

const statusColors = {
  'Em pasto': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
  'Confinamento': 'bg-orange-500/20 text-orange-400 border-orange-500/50',
  'Em trânsito': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50',
  'Vendido': 'bg-slate-500/20 text-slate-400 border-slate-500/50',
  'Desaparecido': 'bg-red-500/20 text-red-400 border-red-500/50',
};

export default function AnimalCard({ animal, onEdit }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="overflow-hidden bg-slate-950/80 backdrop-blur-sm border-slate-800/50 hover:border-emerald-500/50 transition-all duration-300 shadow-xl">
        <div className="relative h-32 bg-gradient-to-br from-emerald-950/30 via-slate-950 to-green-950/30">
          <div className="w-full h-full flex items-center justify-center">
            <Activity className="w-16 h-16 text-emerald-500/30" />
          </div>
          <div className="absolute top-3 right-3">
            <Badge className={`${statusColors[animal.status || 'Em pasto']} border font-bold`}>
              {animal.status || 'Em pasto'}
            </Badge>
          </div>
        </div>

        <CardContent className="p-4 space-y-3">
          <div>
            <h3 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
              {animal.nome || 'Sem nome'}
            </h3>
            <p className="text-sm text-slate-400">{animal.id_eletronico}</p>
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-slate-500">Espécie</p>
              <p className="font-medium text-slate-200">{animal.especie}</p>
            </div>
            <div>
              <p className="text-slate-500">Raça</p>
              <p className="font-medium text-slate-200">{animal.raca || '-'}</p>
            </div>
            <div>
              <p className="text-slate-500">Sexo</p>
              <p className="font-medium text-slate-200">{animal.sexo || '-'}</p>
            </div>
            <div>
              <p className="text-slate-500">Lote</p>
              <p className="font-medium text-slate-200">{animal.lote || '-'}</p>
            </div>
          </div>

          {animal.peso_atual && (
            <div className="flex items-center gap-2 text-sm p-2 bg-slate-900/50 rounded-lg">
              <Weight className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-400">Peso:</span>
              <span className="font-bold text-emerald-400">{animal.peso_atual} kg</span>
            </div>
          )}

          {animal.data_nascimento && (
            <div className="flex items-center gap-2 text-sm p-2 bg-slate-900/50 rounded-lg">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-400">Nascimento:</span>
              <span className="font-medium text-slate-200">
                {format(new Date(animal.data_nascimento), 'dd/MM/yyyy')}
              </span>
            </div>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(animal)}
            className="w-full mt-2 bg-slate-900/50 border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/50 hover:border-emerald-400 font-bold"
          >
            <Pencil className="w-4 h-4 mr-2" />
            Editar Animal
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}