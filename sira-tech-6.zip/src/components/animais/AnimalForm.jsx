import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function AnimalForm({ animal, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(animal || {
    id_eletronico: '',
    nome: '',
    especie: '',
    raca: '',
    sexo: '',
    data_nascimento: '',
    peso_atual: '',
    lote: '',
    fazenda_id: '',
    status: 'Em pasto',
  });

  const { data: fazendas = [] } = useQuery({
    queryKey: ['fazendas'],
    queryFn: () => base44.entities.Fazenda.list(),
    initialData: [],
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="fazenda_id" className="text-emerald-400 font-bold">Fazenda *</Label>
          <Select value={formData.fazenda_id} onValueChange={(value) => handleChange('fazenda_id', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione a fazenda" className="text-emerald-500/50" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              {fazendas.length === 0 ? (
                <SelectItem value="none" disabled className="text-slate-500">
                  Nenhuma fazenda cadastrada
                </SelectItem>
              ) : (
                fazendas.map(fazenda => (
                  <SelectItem key={fazenda.id} value={fazenda.id} className="text-white">
                    {fazenda.nome}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          {fazendas.length === 0 && (
            <p className="text-xs text-orange-400">⚠️ Cadastre uma fazenda primeiro!</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="id_eletronico" className="text-emerald-400 font-bold">ID Eletrônico *</Label>
          <Input
            id="id_eletronico"
            value={formData.id_eletronico}
            onChange={(e) => handleChange('id_eletronico', e.target.value)}
            placeholder="Ex: BR123456789"
            required
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="nome" className="text-emerald-400 font-bold">Nome do Animal</Label>
          <Input
            id="nome"
            value={formData.nome}
            onChange={(e) => handleChange('nome', e.target.value)}
            placeholder="Ex: Mimosa"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="especie" className="text-emerald-400 font-bold">Espécie *</Label>
          <Select value={formData.especie} onValueChange={(value) => handleChange('especie', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" className="text-emerald-500/50" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Bovino" className="text-white">Bovino</SelectItem>
              <SelectItem value="Ovino" className="text-white">Ovino</SelectItem>
              <SelectItem value="Caprino" className="text-white">Caprino</SelectItem>
              <SelectItem value="Suíno" className="text-white">Suíno</SelectItem>
              <SelectItem value="Equino" className="text-white">Equino</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="raca" className="text-emerald-400 font-bold">Raça</Label>
          <Input
            id="raca"
            value={formData.raca}
            onChange={(e) => handleChange('raca', e.target.value)}
            placeholder="Ex: Nelore"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="sexo" className="text-emerald-400 font-bold">Sexo</Label>
          <Select value={formData.sexo} onValueChange={(value) => handleChange('sexo', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" className="text-emerald-500/50" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Macho" className="text-white">Macho</SelectItem>
              <SelectItem value="Fêmea" className="text-white">Fêmea</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="data_nascimento" className="text-emerald-400 font-bold">Data de Nascimento</Label>
          <Input
            id="data_nascimento"
            type="date"
            value={formData.data_nascimento}
            onChange={(e) => handleChange('data_nascimento', e.target.value)}
            className="bg-slate-900/50 border-slate-800 text-white"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="peso_atual" className="text-emerald-400 font-bold">Peso Atual (kg)</Label>
          <Input
            id="peso_atual"
            type="number"
            value={formData.peso_atual}
            onChange={(e) => handleChange('peso_atual', parseFloat(e.target.value))}
            placeholder="Ex: 450"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="lote" className="text-emerald-400 font-bold">Lote</Label>
          <Input
            id="lote"
            value={formData.lote}
            onChange={(e) => handleChange('lote', e.target.value)}
            placeholder="Ex: Lote A"
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-emerald-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="status" className="text-emerald-400 font-bold">Status</Label>
          <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Selecione" className="text-emerald-500/50" />
            </SelectTrigger>
            <SelectContent className="bg-slate-950 border-slate-800 text-white">
              <SelectItem value="Em pasto" className="text-white">Em pasto</SelectItem>
              <SelectItem value="Confinamento" className="text-white">Confinamento</SelectItem>
              <SelectItem value="Em trânsito" className="text-white">Em trânsito</SelectItem>
              <SelectItem value="Vendido" className="text-white">Vendido</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading} className="bg-slate-900/50 border-slate-800 text-slate-300">
          Cancelar
        </Button>
        <Button 
          type="submit" 
          disabled={isLoading || fazendas.length === 0}
          className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50 font-bold"
        >
          {isLoading ? 'Salvando...' : animal ? 'Atualizar' : 'Cadastrar'}
        </Button>
      </div>
    </form>
  );
}