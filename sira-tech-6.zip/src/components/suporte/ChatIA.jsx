import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, Send, Bot, User, Sparkles } from "lucide-react";

const perguntasFrequentes = [
  "Como funciona o rastreamento GPS?",
  "Como cadastrar um novo animal?",
  "Como adicionar um dispositivo IoT?",
  "O que fazer quando um alerta aparece?",
  "Como gerar relatórios?",
  "Como funciona a energia solar?",
  "Como configurar notificações?",
  "Quais animais posso rastrear?",
];

const respostasIA = {
  "Como funciona o rastreamento GPS?": "O SIRA-TECH utiliza dispositivos IoT com GPS integrado que são instalados nos animais (coleiras inteligentes). Esses dispositivos enviam a localização em tempo real via rede LoRa, Wi-Fi ou 4G. Você pode visualizar todos os animais no Mapa de Rastreamento! 🗺️",
  
  "Como cadastrar um novo animal?": "É super simples! Acesse o menu 'Cadastrar Animal' no sidebar ou clique no botão '+Cadastrar Animal' na página de Animais. Preencha os dados como ID eletrônico, espécie, raça, peso e pronto! O sistema já começa a monitorar automaticamente. 🐄",
  
  "Como adicionar um dispositivo IoT?": "Vá em 'Dispositivos IoT' no menu, clique em '+Cadastrar Dispositivo', informe o código do sensor, tipo (GPS Tracker, Sensor de Temperatura, etc.) e associe a um animal. Nossos dispositivos funcionam com energia solar! ☀️",
  
  "O que fazer quando um alerta aparece?": "Os alertas aparecem no Painel Geral em tempo real. Clique no alerta para ver detalhes como tipo (Fora da área, Sem sinal, etc.), localização e severidade. Você pode marcar como 'Em análise' ou 'Resolvido'. Alertas críticos requerem ação imediata! ⚠️",
  
  "Como gerar relatórios?": "Acesse 'Relatórios e Análises' no menu e escolha o tipo: Desempenho do Rebanho, Sustentabilidade, Saúde, Movimentação ou Financeiro. Selecione o período desejado e clique em 'Gerar Relatório'. Você pode exportar em PDF ou Excel! 📊",
  
  "Como funciona a energia solar?": "Todos os nossos dispositivos IoT são alimentados por painéis solares integrados, tornando o sistema 100% sustentável e autônomo. Não precisa trocar baterias! O nível de carga é monitorado em tempo real no painel de dispositivos. 🌞",
  
  "Como configurar notificações?": "Vá em 'Administração' > 'Notificações'. Você pode ativar/desativar notificações por email, alertas do sistema e relatórios semanais. Configure também o intervalo de atualização automática dos dados! 🔔",
  
  "Quais animais posso rastrear?": "O SIRA-TECH suporta Bovinos (gado), Ovinos (ovelhas), Caprinos (cabras), Suínos (porcos) e Equinos (cavalos). Cada espécie tem ícones específicos e pode ter dispositivos personalizados conforme o tamanho do animal! 🐮🐑🐐🐷🐴",
};

export default function ChatIA({ onClose }) {
  const [mensagens, setMensagens] = useState([
    {
      tipo: 'bot',
      texto: 'Olá! 👋 Sou o assistente virtual do SIRA-TECH. Como posso ajudar você hoje?',
      timestamp: new Date(),
    }
  ]);
  const [inputMensagem, setInputMensagem] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [mensagens]);

  const enviarMensagem = (texto) => {
    if (!texto.trim()) return;

    // Adiciona mensagem do usuário
    const novaMensagemUsuario = {
      tipo: 'user',
      texto: texto,
      timestamp: new Date(),
    };
    setMensagens(prev => [...prev, novaMensagemUsuario]);
    setInputMensagem('');

    // Simula delay da IA
    setTimeout(() => {
      const resposta = respostasIA[texto] || 
        "Desculpe, não entendi sua pergunta. Por favor, escolha uma das opções sugeridas ou entre em contato com nosso suporte pelo email suporte@siratechbrasil.com.br ou telefone (15) 99178-6976. 📞";
      
      const novaMensagemBot = {
        tipo: 'bot',
        texto: resposta,
        timestamp: new Date(),
      };
      setMensagens(prev => [...prev, novaMensagemBot]);
    }, 800);
  };

  const handlePerguntaRapida = (pergunta) => {
    enviarMensagem(pergunta);
  };

  return (
    <div className="flex flex-col h-[600px] bg-slate-950/95 backdrop-blur-sm rounded-xl border border-slate-800 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-950/50 to-green-950/50 border-b border-emerald-900/30 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center shadow-lg" style={{boxShadow: '0 0 20px rgba(0,255,65,0.5)'}}>
              <Bot className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h3 className="font-black text-emerald-400 flex items-center gap-2">
                Assistente SIRA-TECH
                <Sparkles className="w-4 h-4" />
              </h3>
              <p className="text-xs text-slate-500">Online • Responde em segundos</p>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {mensagens.map((msg, index) => (
            <div
              key={index}
              className={`flex gap-3 ${msg.tipo === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.tipo === 'bot' 
                  ? 'bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg' 
                  : 'bg-gradient-to-br from-cyan-500 to-blue-600'
              }`} style={{boxShadow: msg.tipo === 'bot' ? '0 0 15px rgba(0,255,65,0.4)' : '0 0 15px rgba(34,211,238,0.4)'}}>
                {msg.tipo === 'bot' ? (
                  <Bot className="w-5 h-5 text-slate-950" />
                ) : (
                  <User className="w-5 h-5 text-slate-950" />
                )}
              </div>
              <div className={`max-w-[80%] ${msg.tipo === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                <div className={`rounded-2xl p-3 ${
                  msg.tipo === 'bot'
                    ? 'bg-slate-900/80 border border-emerald-500/20 text-slate-200'
                    : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                }`}>
                  <p className="text-sm leading-relaxed">{msg.texto}</p>
                </div>
                <span className="text-xs text-slate-600">
                  {msg.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Quick Questions */}
      {mensagens.length === 1 && (
        <div className="px-4 py-2 border-t border-slate-800">
          <p className="text-xs text-slate-500 mb-2 font-semibold">Perguntas Frequentes:</p>
          <div className="grid grid-cols-2 gap-2">
            {perguntasFrequentes.slice(0, 4).map((pergunta, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handlePerguntaRapida(pergunta)}
                className="text-xs bg-slate-900/50 border-emerald-500/30 text-emerald-400 hover:bg-emerald-950/50 hover:border-emerald-400 font-medium h-auto py-2 px-3 text-left justify-start"
              >
                {pergunta}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-slate-800 p-4">
        <div className="flex gap-2">
          <Input
            value={inputMensagem}
            onChange={(e) => setInputMensagem(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && enviarMensagem(inputMensagem)}
            placeholder="Digite sua pergunta..."
            className="bg-slate-900/50 border-slate-800 text-white placeholder:text-slate-600"
          />
          <Button
            onClick={() => enviarMensagem(inputMensagem)}
            className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg shadow-emerald-500/50"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-slate-600 mt-2">
          Ou escolha uma das perguntas frequentes acima
        </p>
      </div>
    </div>
  );
}